<?php
session_start();
include '../config/koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

// Cek apakah ada parameter id
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('ID kategori tidak valid!'); window.location.href='data_kategori.php';</script>";
    exit();
}

$id_kategori = $_GET['id'];

// Validasi ID kategori (pastikan hanya angka)
if (!is_numeric($id_kategori)) {
    echo "<script>alert('ID kategori tidak valid!'); window.location.href='data_kategori.php';</script>";
    exit();
}

// Cek apakah kategori masih digunakan dalam tabel arsip (opsional)
// Kemungkinan nama kolom: id_kategori, kategori_id, atau nama_kategori
$cek_arsip = mysqli_query($koneksi, "SELECT COUNT(*) as jumlah FROM tb_arsip WHERE id_kategori = '$id_kategori'");

// Jika query berhasil, lakukan pengecekan
if ($cek_arsip) {
    $data_arsip = mysqli_fetch_assoc($cek_arsip);
    
    if ($data_arsip['jumlah'] > 0) {
        echo "<script>
            alert('Kategori tidak dapat dihapus karena masih digunakan dalam " . $data_arsip['jumlah'] . " arsip!');
            window.location.href='data_kategori.php';
        </script>";
        exit();
    }
} else {
    // Jika tabel tb_arsip tidak ada atau struktur berbeda, lewati pengecekan
    // echo "<!-- Pengecekan relasi dilewati: " . mysqli_error($koneksi) . " -->";
}

// Hapus data kategori
$query_hapus = mysqli_query($koneksi, "DELETE FROM tb_kategori WHERE id_kategori = '$id_kategori'");

if ($query_hapus) {
    echo "<script>
        alert('Data kategori berhasil dihapus!');
        window.location.href='data_kategori.php';
    </script>";
} else {
    echo "<script>
        alert('Gagal menghapus data kategori: " . mysqli_error($koneksi) . "');
        window.location.href='data_kategori.php';
    </script>";
}
?>