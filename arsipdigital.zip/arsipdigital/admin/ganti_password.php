<?php
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: ../login_admin.php");
    exit();
}

$username = $_SESSION['username'];
$pesan = "";

/* -----------------------------
   1. MIGRASI PASSWORD OTOMATIS
------------------------------*/
$result = mysqli_query($koneksi, "SELECT id_admin, username, password FROM tb_admin");

while ($row = mysqli_fetch_assoc($result)) {
    $id_admin = $row['id_admin'];
    $password = $row['password'];

    // Cek apakah password sudah hash atau masih plain text
    if (strlen($password) < 60 || substr($password, 0, 4) !== '$2y$') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        mysqli_query($koneksi, "UPDATE tb_admin SET password='$hash' WHERE id_admin='$id_admin'");
    }
}

/* -----------------------------
   2. PROSES GANTI PASSWORD
------------------------------*/
if (isset($_POST['simpan'])) {
    $password_lama   = mysqli_real_escape_string($koneksi, $_POST['password_lama']);
    $password_baru   = mysqli_real_escape_string($koneksi, $_POST['password_baru']);
    $konfirmasi_baru = mysqli_real_escape_string($koneksi, $_POST['konfirmasi_baru']);

    // Ambil password lama dari database
    $query = mysqli_query($koneksi, "SELECT password FROM tb_admin WHERE username='$username'");
    $data  = mysqli_fetch_assoc($query);

    if ($data) {
        // Verifikasi password lama
        if (password_verify($password_lama, $data['password']) || $password_lama === $data['password']) {
            // Cek konfirmasi password baru
            if ($password_baru === $konfirmasi_baru) {
                $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);
                $update = mysqli_query($koneksi, "UPDATE tb_admin SET password='$password_hash' WHERE username='$username'");

                if ($update) {
                    $pesan = "<div class='alert alert-success'>Password berhasil diubah!</div>";
                } else {
                    $pesan = "<div class='alert alert-danger'>Terjadi kesalahan, password gagal diubah.</div>";
                }
            } else {
                $pesan = "<div class='alert alert-warning'>Konfirmasi password baru tidak sama!</div>";
            }
        } else {
            $pesan = "<div class='alert alert-danger'>Password lama salah!</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ganti Password - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .password-card {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      border: 1px solid rgba(200, 168, 255, 0.2);
      max-width: 600px;
      margin: 0 auto;
    }
    
    .password-header {
      text-align: center;
      margin-bottom: 25px;
      color: #6B46C1;
    }
    
    .password-header i {
      font-size: 2.5rem;
      margin-bottom: 15px;
      display: block;
      color: #8B5DFF;
    }
    
    .password-header h4 {
      font-weight: 600;
      margin-bottom: 5px;
    }
    
    .form-label {
      font-weight: 600;
      color: #6B46C1;
      margin-bottom: 8px;
    }
    
    .form-control {
      border-radius: 12px;
      padding: 12px 15px;
      border: 1px solid rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .form-control:focus {
      border-color: #8B5DFF;
      box-shadow: 0 0 0 0.25rem rgba(139, 93, 255, 0.25);
    }
    
    .btn-primary {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 12px;
      padding: 12px 25px;
      font-weight: 600;
      width: 100%;
      margin-top: 10px;
      transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(139, 93, 255, 0.4);
      background: linear-gradient(45deg, #7C4DFF, #8B5DFF);
    }
    
    .alert {
      border-radius: 12px;
      padding: 15px 20px;
      margin-bottom: 20px;
      border: none;
    }
    
    .alert-success {
      background: linear-gradient(45deg, #48BB78, #38A169);
      color: white;
    }
    
    .alert-danger {
      background: linear-gradient(45deg, #F56565, #E53E3E);
      color: white;
    }
    
    .alert-warning {
      background: linear-gradient(45deg, #ECC94B, #D69E2E);
      color: white;
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .main-content {
        padding: 20px;
      }
      
      .password-card {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php" class="active">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Ganti Password - Sistem Informasi Arsip Digital</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="ganti_password.php"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="password-card">
      <div class="password-header">
        <i class="fas fa-key"></i>
        <h4>Ganti Password</h4>
        <p>Ubah password akun administrator Anda</p>
      </div>
      
      <?php echo $pesan; ?>
      
      <form method="POST">
        <div class="mb-4">
          <label for="password_lama" class="form-label">Password Lama</label>
          <input type="password" class="form-control" id="password_lama" name="password_lama" required>
        </div>
        
        <div class="mb-4">
          <label for="password_baru" class="form-label">Password Baru</label>
          <input type="password" class="form-control" id="password_baru" name="password_baru" required>
        </div>
        
        <div class="mb-4">
          <label for="konfirmasi_baru" class="form-label">Konfirmasi Password Baru</label>
          <input type="password" class="form-control" id="konfirmasi_baru" name="konfirmasi_baru" required>
        </div>
        
        <button type="submit" name="simpan" class="btn btn-primary">
          <i class="fas fa-save me-2"></i>Simpan Perubahan
        </button>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>