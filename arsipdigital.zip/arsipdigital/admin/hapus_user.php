<?php
include '../config/koneksi.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: data_user.php");
    exit();
}

$id_user = $_GET['id'];

// Ambil data user untuk hapus foto juga
$query = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE id_user='$id_user'");
$data = mysqli_fetch_assoc($query);

if ($data) {
    // Hapus foto jika ada
    if (!empty($data['foto']) && file_exists("../foto/" . $data['foto'])) {
        unlink("../foto/" . $data['foto']);
    }

    // Hapus dari database
    $delete = mysqli_query($koneksi, "DELETE FROM tb_user WHERE id_user='$id_user'");
    if ($delete) {
        echo "<script>alert('Data user berhasil dihapus!');window.location='data_user.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data!');window.location='data_user.php';</script>";
    }
} else {
    echo "<script>alert('Data user tidak ditemukan!');window.location='data_user.php';</script>";
}
?>
