<?php
// edit_arsip.php
session_start();
include "../config/koneksi.php";

if(!isset($_SESSION['username'])){
    header("Location: ../login_admin.php");
    exit;
}

$id = $_GET['id'] ?? 0;
$query = mysqli_query($koneksi, "SELECT * FROM arsip WHERE id='$id'");
$data = mysqli_fetch_assoc($query);
$qkategori = mysqli_query($koneksi, "SELECT * FROM tb_kategori");
$qpetugas = mysqli_query($koneksi, "SELECT * FROM tb_petugas");

if(!$data){
    echo "Data tidak ditemukan.";
    exit;
}

// proses update
if(isset($_POST['update'])){
    $kode_arsip = $_POST['kode_arsip'];
    $nama_arsip = $_POST['nama_arsip'];
    $id_kategori = $_POST['id_kategori'];
    $id_petugas  = $_POST['id_petugas'];
    $keterangan = $_POST['keterangan'];

   $update = mysqli_query($koneksi, "UPDATE arsip SET 
    kode_arsip='$kode_arsip',
    nama_arsip='$nama_arsip',
    id_kategori='$id_kategori',
    id_petugas='$id_petugas',
    keterangan='$keterangan'
    WHERE id='$id'");

    if($update){
        header("Location: data_arsip.php?sukses=update");
        exit;
    } else {
        echo "Gagal update data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Arsip - Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #ec4899 0%, #be185d 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(236, 72, 153, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #f472b6, #ec4899);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #fecaca;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #fecaca, #fbb6ce);
            color: #be185d;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(254, 202, 202, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #ffffff, #fef7ff);
            padding: 15px 30px;
            box-shadow: 0 2px 20px rgba(236, 72, 153, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(236, 72, 153, 0.1);
        }
        
        .welcome-text h1 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .welcome-text p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: linear-gradient(45deg, #ec4899, #be185d);
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .user-info img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-info .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .user-info .user-role {
            font-size: 0.75rem;
            opacity: 0.9;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .form-card {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .form-card-header {
            padding-bottom: 20px;
            margin-bottom: 25px;
            border-bottom: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .form-card-header h4 {
            color: #be185d;
            font-weight: 600;
            margin: 0;
        }
        
        .form-card-header p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .form-label {
            color: #be185d;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border: 1px solid rgba(244, 114, 182, 0.3);
            border-radius: 12px;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #ec4899;
            box-shadow: 0 0 0 0.25rem rgba(236, 72, 153, 0.25);
        }
        
        .btn-warning {
            background: linear-gradient(45deg, #ec4899, #f472b6);
            border: none;
            border-radius: 12px;
            padding: 12px 25px;
            color: white;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-warning:hover {
            background: linear-gradient(45deg, #db2777, #ec4899);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.4);
            color: white;
        }
        
        .btn-secondary {
            background: linear-gradient(45deg, #9ca3af, #6b7280);
            border: none;
            border-radius: 12px;
            padding: 12px 25px;
            color: white;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(45deg, #6b7280, #4b5563);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(107, 114, 128, 0.4);
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php" class="active">
            <i class="fas fa-folder-open"></i>
            Data Arsip
        </a>
        <a href="data_kategori.php">
            <i class="fas fa-tags"></i>
            Data Kategori
        </a>
        <a href="data_user.php">
            <i class="fas fa-users"></i>
            Data User
        </a>
        <a href="riwayat_unduh.php">
            <i class="fas fa-download"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="welcome-text">
            <h1>Edit Arsip</h1>
            <p>Perbarui informasi arsip digital</p>
        </div>
        
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=Petugas+4&background=ec4899&color=fff" alt="User">
            <div class="user-details">
                <div class="user-name">Petugas 4</div>
                <div class="user-role">Petugas</div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Data Arsip</span>
            <i class="fas fa-chevron-right"></i>
            <span>Edit Arsip</span>
        </div>
        
        <!-- Form Card -->
        <div class="form-card">
            <div class="form-card-header">
                <h4><i class="fas fa-edit me-2"></i>Form Edit Arsip</h4>
                <p>Perbarui informasi arsip digital pada form di bawah ini</p>
            </div>
            
            <form method="POST">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Kode Arsip</label>
                            <input type="text" name="kode_arsip" value="<?= $data['kode_arsip'] ?>" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Nama Arsip</label>
                            <input type="text" name="nama_arsip" value="<?= $data['nama_arsip'] ?>" class="form-control" required>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select name="id_kategori" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php 
                                // Reset pointer untuk query kategori
                                mysqli_data_seek($qkategori, 0);
                                while($k = mysqli_fetch_assoc($qkategori)) { 
                                ?>
                                    <option value="<?= $k['id_kategori']; ?>" 
                                        <?= ($data['id_kategori'] == $k['id_kategori']) ? 'selected' : ''; ?>>
                                        <?= $k['nama_kategori']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Petugas</label>
                            <select name="id_petugas" class="form-select" required>
                                <option value="">-- Pilih Petugas --</option>
                                <?php 
                                // Reset pointer untuk query petugas
                                mysqli_data_seek($qpetugas, 0);
                                while($p = mysqli_fetch_assoc($qpetugas)) { 
                                ?>
                                    <option value="<?= $p['id_petugas']; ?>" 
                                        <?= ($data['id_petugas'] == $p['id_petugas']) ? 'selected' : ''; ?>>
                                        <?= $p['nama']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="4"><?= $data['keterangan'] ?></textarea>
                </div>
                
                <div class="d-flex gap-2">
                    <button type="submit" name="update" class="btn btn-warning">
                        <i class="fas fa-save me-2"></i>Update Arsip
                    </button>
                    <a href="data_arsip.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add some interactive effects
document.querySelectorAll('.form-control, .form-select').forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });
});
</script>
</body>
</html>