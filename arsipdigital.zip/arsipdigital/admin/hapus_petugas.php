<?php
session_start();
include '../config/koneksi.php';

// Cek login admin
if (!isset($_SESSION['username'])) {
    header("Location: ../login_admin.php");
    exit();
}

// Ambil id petugas dari URL
$id_petugas = $_GET['id'] ?? '';

if ($id_petugas) {
    $delete = "DELETE FROM tb_petugas WHERE id_petugas = ?";
    $stmt = $koneksi->prepare($delete);
    $stmt->bind_param("i", $id_petugas);
    $stmt->execute();
}

header("Location: data_petugas.php");
exit;
