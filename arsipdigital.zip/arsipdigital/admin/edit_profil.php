<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil - Sistem Arsip Elektronik</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --accent: #e74c3c;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --success: #2ecc71;
            --warning: #f39c12;
            --danger: #e74c3c;
            --gray: #95a5a6;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Header Styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo h1 {
            font-size: 1.5rem;
            color: var(--primary);
            margin-left: 10px;
        }

        .logo i {
            color: var(--secondary);
            font-size: 1.8rem;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }

        /* Page Title */
        .page-title {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .page-title h1 {
            font-size: 1.8rem;
            color: var(--dark);
            display: flex;
            align-items: center;
        }

        .page-title i {
            margin-right: 10px;
            color: var(--secondary);
        }

        .back-button {
            padding: 8px 15px;
            background: var(--gray);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            transition: var(--transition);
            text-decoration: none;
        }

        .back-button:hover {
            background: #7f8c8d;
        }

        .back-button i {
            margin-right: 5px;
        }

        /* Main Content */
        .main-content {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 20px;
        }

        /* Profile Card */
        .profile-card {
            background: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
            padding: 25px;
            text-align: center;
            height: fit-content;
        }

        .profile-img-container {
            position: relative;
            display: inline-block;
            margin-bottom: 20px;
        }

        .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--secondary);
        }

        .change-img-btn {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: var(--secondary);
            color: white;
            border: none;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .change-img-btn:hover {
            background: #2980b9;
        }

        .profile-info h2 {
            font-size: 1.8rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .profile-info p {
            color: var(--gray);
            margin-bottom: 10px;
        }

        .badge {
            display: inline-block;
            padding: 5px 10px;
            background: var(--secondary);
            color: white;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-bottom: 20px;
        }

        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 25px;
        }

        /* Button Styles */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-primary {
            background: var(--secondary);
            color: white;
        }

        .btn-primary:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #27ae60;
            transform: translateY(-2px);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }

        /* Form Section */
        .form-section {
            background: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
            padding: 25px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .section-header h2 {
            font-size: 1.5rem;
            color: var(--dark);
            display: flex;
            align-items: center;
        }

        .section-header i {
            margin-right: 10px;
            color: var(--secondary);
        }

        /* Form Grid */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 8px;
        }

        .form-group input, 
        .form-group textarea, 
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-group input:focus, 
        .form-group textarea:focus, 
        .form-group select:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }

        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 40px;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .header {
                flex-direction: column;
                text-align: center;
            }
            
            .user-info {
                margin-top: 10px;
            }
            
            .page-title {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .back-button {
                margin-top: 10px;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">
                <i class="fas fa-archive"></i>
                <h1>Sistem Arsip Elektronik</h1>
            </div>
            <div class="user-info">
                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Admin">
                <div>
                    <h4>Admin User</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <!-- Page Title -->
        <div class="page-title">
            <h1><i class="fas fa-user-edit"></i> Edit Profil</h1>
            <a href="profil_saya.php" class="back-button">
                <i class="fas fa-arrow-left"></i> Kembali ke Profil
            </a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Profile Card -->
            <div class="profile-card">
                <div class="profile-img-container">
                    <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Admin" class="profile-img">
                    <button class="change-img-btn">
                        <i class="fas fa-camera"></i>
                    </button>
                </div>
                <div class="profile-info">
                    <h2>Muhammad Rizky</h2>
                    <p>rizky@arsip-elektronik.com</p>
                    <span class="badge">Administrator</span>
                    
                    <div class="action-buttons">
                        <a href="profil_saya.php" class="btn btn-primary">
                            <i class="fas fa-user"></i> Lihat Profil
                        </a>
                        <a href="ganti_password.php" class="btn btn-danger">
                            <i class="fas fa-lock"></i> Ganti Password
                        </a>
                    </div>
                </div>
            </div>

            <!-- Form Section -->
            <div class="form-section">
                <div class="section-header">
                    <h2><i class="fas fa-user-edit"></i> Form Edit Profil</h2>
                </div>

               <form id="editProfileForm" action="proses_edit_profil.php" method="POST">
    <div class="form-grid">
        <div class="form-group">
            <label for="fullname">Nama Lengkap</label>
            <input type="text" id="fullname" name="fullname" value="<?php echo $data_profil['fullname']; ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo $data_profil['email']; ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">Nomor Telepon</label>
            <input type="tel" id="phone" name="phone" value="<?php echo $data_profil['phone']; ?>">
        </div>
        <div class="form-group">
            <label for="position">Jabatan</label>
            <input type="text" id="position" name="position" value="<?php echo $data_profil['position']; ?>">
        </div>
        <div class="form-group full-width">
            <label for="address">Alamat</label>
            <textarea id="address" name="address"><?php echo $data_profil['address']; ?></textarea>
        </div>
        <div class="form-group">
            <label for="joinDate">Terdaftar Sejak</label>
            <input type="date" id="joinDate" name="joinDate" value="<?php echo $data_profil['join_date']; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="role">Peran</label>
            <select id="role" name="role" required>
                <option value="admin" <?= ($data_profil['role']=='admin'?'selected':''); ?>>Admin 1</option>
                <option value="user" <?= ($data_profil['role']=='user'?'selected':''); ?>>Admin 2</option>
                <option value="editor" <?= ($data_profil['role']=='editor'?'selected':''); ?>>Admin 3</option>
                <option value="viewer" <?= ($data_profil['role']=='viewer'?'selected':''); ?>>Admin 4</option>
            </select>
        </div>
        <div class="form-group full-width">
            <label for="bio">Bio</label>
            <textarea id="bio" name="bio"><?php echo $data_profil['bio']; ?></textarea>
        </div>
    </div>

    <div class="form-actions">
        <button type="button" class="btn btn-danger" id="cancelButton">
            <i class="fas fa-times"></i> Batal
        </button>
        <button type="submit" class="btn btn-success">
            <i class="fas fa-save"></i> Simpan Perubahan
        </button>
    </div>
</form>

        <!-- Footer -->
        <div class="footer">
            <p>© 2023 Sistem Arsip Elektronik - e-Arsip. All rights reserved.</p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('editProfileForm');
            const cancelButton = document.getElementById('cancelButton');
            
            // Tombol batal
            cancelButton.addEventListener('click', function() {
                if(confirm('Batalkan perubahan?')) {
                    window.location.href = 'profil_saya.php';
                }
            });
            
            // Submit form
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Simulasi penyimpanan data
                const Toast = {
                    init() {
                        this.hideTimeout = null;
                        
                        this.el = document.createElement('div');
                        this.el.className = 'toast';
                        document.body.appendChild(this.el);
                    },
                    
                    show(message, state) {
                        clearTimeout(this.hideTimeout);
                        
                        this.el.textContent = message;
                        this.el.className = 'toast toast--visible';
                        
                        if (state) {
                            this.el.classList.add(`toast--${state}`);
                        }
                        
                        this.hideTimeout = setTimeout(() => {
                            this.el.classList.remove('toast--visible');
                        }, 3000);
                    }
                };
                
                // Buat elemen toast jika belum ada
                if (!document.querySelector('.toast')) {
                    Toast.init();
                    
                    // Style untuk toast
                    const style = document.createElement('style');
                    style.textContent = `
                        .toast {
                            position: fixed;
                            top: 20px;
                            right: 20px;
                            padding: 15px 20px;
                            background: var(--success);
                            color: white;
                            border-radius: 4px;
                            box-shadow: var(--shadow);
                            transform: translateY(-100px);
                            opacity: 0;
                            transition: transform 0.3s ease, opacity 0.3s ease;
                            z-index: 1000;
                        }
                        
                        .toast--visible {
                            transform: translateY(0);
                            opacity: 1;
                        }
                    `;
                    document.head.appendChild(style);
                }
                
                // Tampilkan pesan sukses
                Toast.show('Profil berhasil diperbarui!', 'success');
                
                // Redirect setelah 2 detik
                setTimeout(() => {
                    window.location.href = 'profil_saya.php';
                }, 2000);
            });
            
            // Tombol ganti foto
            document.querySelector('.change-img-btn').addEventListener('click', function() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                
                input.onchange = function(e) {
                    const file = e.target.files[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            document.querySelector('.profile-img').src = event.target.result;
                        };
                        reader.readAsDataURL(file);
                    }
                };
                
                input.click();
            });
        });
    </script>
</body>
</html>