<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 25px;
      margin-bottom: 30px;
    }
    
    .stat-card {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      padding: 25px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      position: relative;
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      border: 1px solid rgba(200, 168, 255, 0.2);
    }
    
    .stat-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 15px 40px rgba(139, 93, 255, 0.25);
    }
    
    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: var(--card-color);
    }
    
    .stat-card.purple { --card-color: linear-gradient(45deg, #8B5DFF, #C8A8FF); }
    .stat-card.violet { --card-color: linear-gradient(45deg, #A855F7, #C084FC); }
    .stat-card.indigo { --card-color: linear-gradient(45deg, #6366F1, #8B5CF6); }
    .stat-card.pink { --card-color: linear-gradient(45deg, #EC4899, #F472B6); }
    
    .stat-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .stat-info h5 {
      color: #6B46C1;
      font-size: 0.9rem;
      margin-bottom: 8px;
      font-weight: 600;
    }
    
    .stat-info .number {
      font-size: 2.2rem;
      font-weight: bold;
      color: #4C1D95;
      margin: 0;
    }
    
    .stat-icon {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      color: white;
      position: relative;
    }
    
    .stat-icon::before {
      content: '';
      position: absolute;
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background: inherit;
      opacity: 0.2;
      transform: scale(1.2);
    }
    
    .stat-card.purple .stat-icon { background: linear-gradient(45deg, #8B5DFF, #C8A8FF); }
    .stat-card.violet .stat-icon { background: linear-gradient(45deg, #A855F7, #C084FC); }
    .stat-card.indigo .stat-icon { background: linear-gradient(45deg, #6366F1, #8B5CF6); }
    .stat-card.pink .stat-icon { background: linear-gradient(45deg, #EC4899, #F472B6); }
    
    .mini-chart {
      margin-top: 15px;
      height: 40px;
      display: flex;
      align-items: end;
      gap: 3px;
    }
    
    .mini-bar {
      background: var(--card-color);
      opacity: 0.3;
      width: 8px;
      border-radius: 4px 4px 0 0;
    }
    
    .chart-card {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      overflow: hidden;
      border: 1px solid rgba(200, 168, 255, 0.2);
    }
    
    .chart-header {
      padding: 20px 25px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      background: linear-gradient(45deg, #faf7ff, #f3e8ff);
    }
    
    .chart-header h5 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
    }
    
    .chart-body {
      padding: 25px;
    }
    
    .info-section {
      background: linear-gradient(135deg, #8B5DFF, #A855F7);
      border-radius: 20px;
      padding: 25px;
      color: white;
      text-align: center;
      margin-top: 30px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.3);
    }
    
    .info-section h4 {
      margin-bottom: 10px;
    }
    
    .info-section p {
      opacity: 0.9;
      margin: 0;
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
      
      .main-content {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php" class="active">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Sistem Informasi Arsip Digital</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="#"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Statistics Cards -->
    <div class="stats-grid">
      <div class="stat-card purple">
        <div class="stat-content">
          <div class="stat-info">
            <h5>Petugas</h5>
            <p class="number">3</p>
          </div>
          <div class="stat-icon">
            <i class="fas fa-users-cog"></i>
          </div>
        </div>
        <div class="mini-chart">
          <div class="mini-bar" style="height: 20px;"></div>
          <div class="mini-bar" style="height: 35px;"></div>
          <div class="mini-bar" style="height: 25px;"></div>
          <div class="mini-bar" style="height: 40px;"></div>
          <div class="mini-bar" style="height: 30px;"></div>
          <div class="mini-bar" style="height: 35px;"></div>
        </div>
      </div>
      
      <div class="stat-card violet">
        <div class="stat-content">
          <div class="stat-info">
            <h5>User / Pengguna</h5>
            <p class="number">6</p>
          </div>
          <div class="stat-icon">
            <i class="fas fa-users"></i>
          </div>
        </div>
        <div class="mini-chart">
          <div class="mini-bar" style="height: 15px;"></div>
          <div class="mini-bar" style="height: 25px;"></div>
          <div class="mini-bar" style="height: 35px;"></div>
          <div class="mini-bar" style="height: 20px;"></div>
          <div class="mini-bar" style="height: 30px;"></div>
          <div class="mini-bar" style="height: 40px;"></div>
        </div>
      </div>
      
      <div class="stat-card indigo">
        <div class="stat-content">
          <div class="stat-info">
            <h5>Total Arsip</h5>
            <p class="number">10</p>
          </div>
          <div class="stat-icon">
            <i class="fas fa-folder"></i>
          </div>
        </div>
        <div class="mini-chart">
          <div class="mini-bar" style="height: 30px;"></div>
          <div class="mini-bar" style="height: 20px;"></div>
          <div class="mini-bar" style="height: 40px;"></div>
          <div class="mini-bar" style="height: 35px;"></div>
          <div class="mini-bar" style="height: 25px;"></div>
          <div class="mini-bar" style="height: 30px;"></div>
        </div>
      </div>
      
      <div class="stat-card pink">
        <div class="stat-content">
          <div class="stat-info">
            <h5>Kategori Arsip</h5>
            <p class="number">8</p>
          </div>
          <div class="stat-icon">
            <i class="fas fa-tags"></i>
          </div>
        </div>
        <div class="mini-chart">
          <div class="mini-bar" style="height: 25px;"></div>
          <div class="mini-bar" style="height: 35px;"></div>
          <div class="mini-bar" style="height: 20px;"></div>
          <div class="mini-bar" style="height: 40px;"></div>
          <div class="mini-bar" style="height: 30px;"></div>
          <div class="mini-bar" style="height: 25px;"></div>
        </div>
      </div>
    </div>

    <!-- Chart Section -->
    <div class="chart-card">
      <div class="chart-header">
        <h5><i class="fas fa-chart-line me-2"></i>Grafik Pengunduhan Arsip</h5>
        <small class="text-muted">Grafik jumlah unduh arsip perhari selama sebulan</small>
      </div>
      <div class="chart-body">
        <canvas id="grafikUnduh" height="100"></canvas>
      </div>
    </div>

    <!-- Info Section -->
    <div class="info-section">
      <h4><i class="fas fa-rocket me-2"></i>Administrator</h4>
      <p>Pengelolaan arsip jadi lebih mudah dengan sistem informasi arsip digital</p>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Sample data for chart
const sampleDates = ['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-06', '2024-01-07'];
const sampleData = [0, 1, 0, 2, 1, 3, 1];

const ctx = document.getElementById('grafikUnduh');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: sampleData.map((_, index) => `Hari ${index + 1}`),
        datasets: [{
            label: 'Jumlah Unduhan',
            data: sampleData,
            borderColor: '#8B5DFF',
            backgroundColor: 'rgba(139, 93, 255, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#8B5DFF',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverRadius: 8,
            pointHoverBackgroundColor: '#A855F7',
            pointHoverBorderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    usePointStyle: true,
                    font: {
                        size: 12
                    },
                    color: '#6B46C1'
                }
            }
        },
        scales: {
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    font: {
                        size: 11
                    },
                    color: '#6B46C1'
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(139, 93, 255, 0.1)'
                },
                ticks: {
                    font: {
                        size: 11
                    },
                    color: '#6B46C1'
                }
            }
        },
        elements: {
            point: {
                hoverBackgroundColor: '#8B5DFF'
            }
        }
    }
});

// Add some interactive effects
document.querySelectorAll('.stat-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-8px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0) scale(1)';
    });
});
</script>
</body>
</html>