<?php
// hapus_arsip.php
session_start();
include "../config/koneksi.php";

if(!isset($_SESSION['username'])){
    header("Location: ../login_admin.php");
    exit;
}

$id = $_GET['id'] ?? 0;

// ambil data dulu untuk hapus file jika perlu
$get = mysqli_query($koneksi, "SELECT * FROM arsip WHERE id='$id'");
$data = mysqli_fetch_assoc($get);

if($data){
    // jika ada file di folder, hapus juga
    if(file_exists($data['file_path'])){
        unlink($data['file_path']);
    }

    $delete = mysqli_query($koneksi, "DELETE FROM arsip WHERE id='$id'");

    if($delete){
        header("Location: data_arsip.php?sukses=hapus");
        exit;
    } else {
        echo "Gagal menghapus data.";
    }
} else {
    echo "Data tidak ditemukan.";
}
?>
