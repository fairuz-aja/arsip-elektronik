<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "arsipdigital";

// Perhatikan nama variabel harus $koneksi
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Tambahkan pengecekan error
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
