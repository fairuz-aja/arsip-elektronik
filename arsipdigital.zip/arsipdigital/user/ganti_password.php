<?php
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'User') {
    header("Location: ../login_user.php");
    exit();
}

$username = $_SESSION['username'];
$pesan = "";

/* -----------------------------
   1. MIGRASI PASSWORD OTOMATIS
------------------------------*/
$result = mysqli_query($koneksi, "SELECT id_user, username, password FROM tb_user");

while ($row = mysqli_fetch_assoc($result)) {
    $id_user = $row['id_user'];
    $password = $row['password'];

    // Cek apakah password sudah hash atau masih plain text
    if (strlen($password) < 60 || substr($password, 0, 4) !== '$2y$') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        mysqli_query($koneksi, "UPDATE user SET password='$hash' WHERE id_user='$id_user'");
    }
}

/* -----------------------------
   2. PROSES GANTI PASSWORD
------------------------------*/
if (isset($_POST['simpan'])) {
    $password_lama   = mysqli_real_escape_string($koneksi, $_POST['password_lama']);
    $password_baru   = mysqli_real_escape_string($koneksi, $_POST['password_baru']);
    $konfirmasi_baru = mysqli_real_escape_string($koneksi, $_POST['konfirmasi_baru']);

    // Ambil password lama dari database
    $query = mysqli_query($koneksi, "SELECT password FROM tb_user WHERE username='$username'");
    $data  = mysqli_fetch_assoc($query);

    if ($data) {
        // Verifikasi password lama
        if (password_verify($password_lama, $data['password']) || $password_lama === $data['password']) {
            // Cek konfirmasi password baru
            if ($password_baru === $konfirmasi_baru) {
                $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);
                $update = mysqli_query($koneksi, "UPDATE tb_user SET password='$password_hash' WHERE username='$username'");

                if ($update) {
                    $pesan = "<div class='alert alert-success'>Password berhasil diubah!</div>";
                } else {
                    $pesan = "<div class='alert alert-danger'>Terjadi kesalahan, password gagal diubah.</div>";
                }
            } else {
                $pesan = "<div class='alert alert-warning'>Konfirmasi password baru tidak sama!</div>";
            }
        } else {
            $pesan = "<div class='alert alert-danger'>Password lama salah!</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password | Sistem Informasi Arsip Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<style>
:root {
    --primary: #2563eb;
    --primary-dark: #1d4ed8;
    --primary-light: #dbeafe;
    --primary-gradient: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
    --primary-gradient-light: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
    --secondary: #4f46e5;
    --accent: #6366f1;
    --success: #10b981;
    --info: #06b6d4;
    --warning: #f59e0b;
    --danger: #ef4444;
    --dark: #1e293b;
    --light-blue: #e0f2fe;
    --light-blue-2: #bae6fd;
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
    --gray-900: #0f172a;
    --white: #ffffff;
    --shadow-sm: 0 1px 3px rgba(37, 99, 235, 0.12);
    --shadow: 0 4px 6px rgba(37, 99, 235, 0.15);
    --shadow-md: 0 5px 15px rgba(37, 99, 235, 0.2);
    --shadow-lg: 0 10px 25px rgba(37, 99, 235, 0.25);
    --border-radius: 12px;
    --border-radius-lg: 16px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    color: var(--gray-800);
    line-height: 1.6;
    font-size: 15px;
    min-height: 100vh;
}

.container {
    display: flex;
    min-height: 100vh;
}

/* Sidebar Styles */
.sidebar {
    width: 280px;
    background: var(--primary-gradient);
    box-shadow: var(--shadow-md);
    transition: var(--transition);
    z-index: 100;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.sidebar-header {
    padding: 24px;
    text-align: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header .logo {
    font-weight: 700;
    font-size: 24px;
    color: var(--white);
    letter-spacing: 0.5px;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.sidebar-nav {
    padding: 24px 16px;
    flex-grow: 1;
}

.sidebar-nav ul {
    list-style: none;
}

.sidebar-nav ul li {
    margin-bottom: 8px;
}

.sidebar-nav ul li a {
    display: flex;
    align-items: center;
    padding: 14px 16px;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.9);
    font-weight: 500;
    border-radius: var(--border-radius);
    transition: var(--transition);
}

.sidebar-nav ul li a:hover,
.sidebar-nav ul li a.active {
    background: rgba(255, 255, 255, 0.15);
    color: var(--white);
    backdrop-filter: blur(10px);
}

.sidebar-nav ul li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 24px;
    text-align: center;
}

.sidebar-footer {
    padding: 16px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    text-align: center;
    color: rgba(255, 255, 255, 0.7);
    font-size: 13px;
}

/* Main Content Styles */
.main-content {
    flex-grow: 1;
    padding: 30px;
    overflow-y: auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--white);
    padding: 20px 28px;
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow);
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}

.header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
    background: var(--primary-gradient);
}

.header h1 {
    color: var(--primary-dark);
    font-weight: 700;
    font-size: 28px;
    letter-spacing: -0.5px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 16px;
}

.welcome-text {
    color: var(--gray-600);
    font-size: 15px;
    font-weight: 500;
}

.welcome-text .username {
    color: var(--primary);
    font-weight: 600;
}

.user-dropdown {
    position: relative;
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    padding: 10px 16px;
    border-radius: var(--border-radius);
    transition: var(--transition);
    background: var(--light-blue);
    border: 1px solid var(--primary-light);
}

.user-dropdown:hover {
    background: var(--primary-light);
    box-shadow: var(--shadow-sm);
}

.profile-img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--primary-gradient);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    font-weight: 700;
    color: var(--white);
    box-shadow: var(--shadow-sm);
}

.user-details {
    display: flex;
    flex-direction: column;
}

.user-details span:first-child {
    font-weight: 600;
    color: var(--gray-800);
    font-size: 14px;
}

.user-details span:last-child {
    font-size: 12px;
    color: var(--gray-500);
}

.dropdown-arrow {
    font-size: 12px;
    color: var(--primary);
    transition: var(--transition);
}

.user-dropdown.active .dropdown-arrow {
    transform: rotate(180deg);
}

.dropdown-menu {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-lg);
    border: 1px solid var(--primary-light);
    min-width: 220px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: var(--transition);
    z-index: 1000;
    overflow: hidden;
}

.dropdown-menu.show {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.dropdown-header {
    padding: 16px;
    border-bottom: 1px solid var(--gray-100);
    background: var(--light-blue);
}

.dropdown-header h6 {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    color: var(--primary-dark);
}

.dropdown-header p {
    margin: 4px 0 0 0;
    font-size: 12px;
    color: var(--primary);
}

.dropdown-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    text-decoration: none;
    color: var(--gray-700);
    font-size: 14px;
    font-weight: 500;
    transition: var(--transition);
    border: none;
    background: none;
    width: 100%;
    cursor: pointer;
}

.dropdown-item:hover {
    background: var(--light-blue);
    color: var(--primary);
    padding-left: 20px;
}

.dropdown-item i {
    font-size: 16px;
    width: 16px;
    text-align: center;
    color: var(--primary);
}

.dropdown-divider {
    height: 1px;
    background: var(--gray-200);
    margin: 4px 0;
}

/* Breadcrumb */
.breadcrumb {
    margin: 0 0 28px;
    font-size: 14px;
    color: var(--gray-500);
    display: flex;
    align-items: center;
    gap: 8px;
}

.breadcrumb a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
}

.breadcrumb a:hover {
    color: var(--primary-dark);
    text-decoration: underline;
}

.breadcrumb i {
    font-size: 12px;
    color: var(--gray-400);
}

/* Password Card */
.password-card {
    background: var(--white);
    padding: 28px;
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow);
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
    max-width: 600px;
    margin: 0 auto;
}

.password-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--primary-gradient);
}

.password-card h4 {
    font-size: 22px;
    font-weight: 700;
    margin-bottom: 24px;
    color: var(--primary-dark);
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: var(--gray-700);
    font-size: 14px;
}

.form-control {
    width: 100%;
    padding: 14px 16px;
    border: 1px solid var(--gray-300);
    border-radius: var(--border-radius);
    font-size: 15px;
    transition: var(--transition);
    background-color: var(--white);
}

.form-control:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

.btn-primary {
    background: var(--primary-gradient);
    color: var(--white);
    border: none;
    padding: 14px 24px;
    border-radius: var(--border-radius);
    font-weight: 600;
    font-size: 15px;
    cursor: pointer;
    transition: var(--transition);
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: 10px;
}

.btn-primary:hover {
    background: var(--primary-gradient-light);
    box-shadow: var(--shadow-md);
    transform: translateY(-2px);
}

.alert {
    padding: 16px;
    border-radius: var(--border-radius);
    margin-bottom: 24px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert-success {
    background-color: #ecfdf5;
    color: #065f46;
    border-left: 4px solid #10b981;
}

.alert-danger {
    background-color: #fef2f2;
    color: #7f1d1d;
    border-left: 4px solid #ef4444;
}

.alert-warning {
    background-color: #fffbeb;
    color: #92400e;
    border-left: 4px solid #f59e0b;
}

/* Mobile Responsive */
@media (max-width: 992px) {
    .container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
    }
    
    .sidebar-nav {
        padding: 16px;
    }
    
    .sidebar-nav ul {
        display: flex;
        overflow-x: auto;
        padding-bottom: 8px;
    }
    
    .sidebar-nav ul li {
        margin-bottom: 0;
        margin-right: 8px;
    }
    
    .main-content {
        padding: 20px;
    }

    .header {
        flex-direction: column;
        gap: 16px;
        text-align: center;
        padding: 20px;
    }

    .header h1 {
        font-size: 24px;
    }

    .password-card {
        padding: 20px;
    }
}

@media (max-width: 576px) {
    .main-content {
        padding: 16px;
    }
    
    .user-info {
        flex-direction: column;
        gap: 12px;
    }
    
    .user-dropdown {
        width: 100%;
        justify-content: center;
    }
    
    .password-card h4 {
        font-size: 20px;
    }
}

/* Smooth animations */
.password-card {
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInUp 0.5s ease forwards;
    animation-delay: 0.1s;
}

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Scrollbar styling */
.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.5);
}
</style>

<body>
    <div class="container">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo">SISTEM ARSIP DIGITAL</div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="dashboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="data_arsip.php">
                            <i class="fas fa-archive"></i>
                            <span>Data Arsip</span>
                        </a>
                    </li>
                    <li>
                        <a href="ganti_password.php" class="active">
                            <i class="fas fa-key"></i>
                            <span>Ganti Password</span>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                &copy; 2025 Sistem Informasi Arsip Digital
            </div>
        </div>

        <div class="main-content">
            <div class="header">
                <h1>Ganti Password</h1>
                <div class="user-info">
                    <div class="welcome-text">
                        Selamat datang, <span class="username"><?php echo $_SESSION['username']; ?></span>
                    </div>
                    
                    <div class="user-dropdown" onclick="toggleDropdown()">
                        <div class="profile-img"><?php echo substr($_SESSION['username'], 0, 1); ?></div>
                        <div class="user-details">
                            <span><?php echo $_SESSION['username']; ?></span>
                            <span><?php echo $_SESSION['role']; ?></span>
                        </div>
                        <i class="fas fa-chevron-down dropdown-arrow"></i>
                        
                        <div class="dropdown-menu" id="userDropdown">
                            <div class="dropdown-header">
                                <h6><?php echo $_SESSION['username']; ?></h6>
                                <p><?php echo $_SESSION['role']; ?></p>
                            </div>
                            <a href="dashboard.php" class="dropdown-item">
                                <i class="fas fa-user"></i>
                                Profil Saya
                            </a>
                            <a href="ganti_password.php" class="dropdown-item">
                                <i class="fas fa-key"></i>
                                Ganti Password
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item">
                                <i class="fas fa-sign-out-alt"></i>
                                Log Out
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="breadcrumb">
                <a href="dashboard.php"><i class="fas fa-home"></i> Home</a> / Ganti Password
            </div>

            <div class="password-card">
                <h4><i class="fas fa-key"></i> Ganti Password</h4>
                <?php echo $pesan; ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="password_lama" class="form-label">Password Lama</label>
                        <input type="password" class="form-control" id="password_lama" name="password_lama" required>
                    </div>
                    <div class="form-group">
                        <label for="password_baru" class="form-label">Password Baru</label>
                        <input type="password" class="form-control" id="password_baru" name="password_baru" required>
                    </div>
                    <div class="form-group">
                        <label for="konfirmasi_baru" class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" class="form-control" id="konfirmasi_baru" name="konfirmasi_baru" required>
                    </div>
                    <button type="submit" name="simpan" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Perubahan
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            const userDropdown = document.querySelector('.user-dropdown');
            
            dropdown.classList.toggle('show');
            userDropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userDropdown = document.querySelector('.user-dropdown');
            const dropdown = document.getElementById('userDropdown');
            
            if (!userDropdown.contains(event.target)) {
                dropdown.classList.remove('show');
                userDropdown.classList.remove('active');
            }
        });

        // Close dropdown with ESC key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const dropdown = document.getElementById('userDropdown');
                const userDropdown = document.querySelector('.user-dropdown');
                
                dropdown.classList.remove('show');
                userDropdown.classList.remove('active');
            }
        });

        // Add some interactive effects to form inputs
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.style.transform = 'scale(1.02)';
                this.style.boxShadow = '0 5px 15px rgba(37, 99, 235, 0.15)';
            });
            
            input.addEventListener('blur', function() {
                this.style.transform = 'scale(1)';
                this.style.boxShadow = 'none';
            });
        });
    </script>
</body>
</html>