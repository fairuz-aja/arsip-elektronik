<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        --secondary-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        --accent-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        --glass-bg: rgba(255, 255, 255, 0.1);
        --glass-border: rgba(255, 255, 255, 0.2);
        --text-primary: #ffffff;
        --text-secondary: rgba(255, 255, 255, 0.8);
        --shadow-light: 0 8px 32px rgba(31, 38, 135, 0.37);
        --shadow-heavy: 0 20px 60px rgba(0, 0, 0, 0.3);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        background: var(--primary-gradient);
        min-height: 100vh;
        position: relative;
        overflow-x: hidden;
    }

    /* Advanced animated background */
    .bg-animation {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
    }

    .floating-shapes {
        position: absolute;
        width: 100%;
        height: 100%;
    }

    .shape {
        position: absolute;
        background: linear-gradient(45deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
        border-radius: 50%;
        animation: float-around 20s infinite ease-in-out;
    }

    .shape:nth-child(1) {
        width: 80px;
        height: 80px;
        top: 20%;
        left: 10%;
        animation-delay: 0s;
        animation-duration: 25s;
    }

    .shape:nth-child(2) {
        width: 120px;
        height: 120px;
        top: 60%;
        right: 15%;
        animation-delay: 5s;
        animation-duration: 30s;
    }

    .shape:nth-child(3) {
        width: 60px;
        height: 60px;
        bottom: 30%;
        left: 70%;
        animation-delay: 10s;
        animation-duration: 20s;
    }

    .shape:nth-child(4) {
        width: 100px;
        height: 100px;
        top: 10%;
        right: 30%;
        animation-delay: 15s;
        animation-duration: 35s;
    }

    @keyframes float-around {
        0%, 100% {
            transform: translateY(0px) translateX(0px) rotate(0deg);
        }
        25% {
            transform: translateY(-50px) translateX(30px) rotate(90deg);
        }
        50% {
            transform: translateY(-20px) translateX(-40px) rotate(180deg);
        }
        75% {
            transform: translateY(30px) translateX(20px) rotate(270deg);
        }
    }

    /* Particle system */
    .particles {
        position: absolute;
        width: 100%;
        height: 100%;
    }

    .particle {
        position: absolute;
        width: 3px;
        height: 3px;
        background: rgba(255, 255, 255, 0.6);
        border-radius: 50%;
        animation: particle-float 15s infinite linear;
    }

    .particle:nth-child(odd) {
        animation-duration: 20s;
        background: rgba(164, 176, 255, 0.8);
    }

    @keyframes particle-float {
        0% {
            transform: translateY(100vh) translateX(0px);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100px) translateX(100px);
            opacity: 0;
        }
    }

    /* Main container */
    .container {
        display: flex;
        max-width: 1400px;
        width: 95%;
        margin: 0 auto;
        min-height: 100vh;
        align-items: center;
        justify-content: space-between;
        position: relative;
        z-index: 10;
        gap: 80px;
    }

    /* Left content section */
    .left {
        flex: 1;
        max-width: 600px;
        animation: slideInLeft 1.2s cubic-bezier(0.4, 0, 0.2, 1);
    }

    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-80px) translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateX(0) translateY(0);
        }
    }

    /* Animated badge */
    .badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: var(--glass-bg);
        backdrop-filter: blur(20px);
        border: 1px solid var(--glass-border);
        padding: 12px 20px;
        border-radius: 50px;
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 32px;
        position: relative;
        overflow: hidden;
        animation: badge-glow 3s ease-in-out infinite;
    }

    .badge::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        animation: badge-shine 2s infinite;
    }

    @keyframes badge-glow {
        0%, 100% {
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
        }
        50% {
            box-shadow: 0 0 30px rgba(255, 255, 255, 0.4);
        }
    }

    @keyframes badge-shine {
        0% { left: -100%; }
        100% { left: 100%; }
    }

    /* Main heading with advanced effects */
    .left h1 {
        font-size: clamp(2.8rem, 5.5vw, 4.5rem);
        font-weight: 800;
        margin-bottom: 28px;
        background: linear-gradient(135deg, #ffffff 0%, #a4b0ff 50%, #ffeaa7 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        line-height: 1.1;
        letter-spacing: -0.02em;
        position: relative;
        animation: text-glow 4s ease-in-out infinite;
    }

    @keyframes text-glow {
        0%, 100% {
            filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.3));
        }
        50% {
            filter: drop-shadow(0 0 20px rgba(164, 176, 255, 0.5));
        }
    }

    .left p {
        font-size: 1.25rem;
        color: var(--text-secondary);
        margin-bottom: 48px;
        line-height: 1.7;
        font-weight: 400;
        animation: fadeInUp 1s ease-out 0.3s both;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Advanced button styling */
    .btn-group {
        display: flex;
        flex-direction: column;
        gap: 20px;
        max-width: 450px;
        animation: fadeInUp 1s ease-out 0.6s both;
    }

    .btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
        padding: 18px 40px;
        border-radius: 20px;
        text-decoration: none;
        font-weight: 600;
        font-size: 1.1rem;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        border: none;
        cursor: pointer;
        backdrop-filter: blur(20px);
    }

    .btn-primary {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        color: white;
        box-shadow: 0 15px 35px rgba(79, 172, 254, 0.4);
    }

    .btn-secondary {
        background: rgba(255, 255, 255, 0.15);
        color: white;
        border: 2px solid rgba(255, 255, 255, 0.3);
        box-shadow: 0 15px 35px rgba(255, 255, 255, 0.1);
    }

    /* Advanced button hover effects */
    .btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left 0.6s;
    }

    .btn::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, transparent 70%);
        transition: all 0.6s;
        transform: translate(-50%, -50%);
        border-radius: 50%;
    }

    .btn:hover::before {
        left: 100%;
    }

    .btn:hover::after {
        width: 300px;
        height: 300px;
    }

    .btn:hover {
        transform: translateY(-5px) scale(1.02);
    }

    .btn-primary:hover {
        box-shadow: 0 25px 50px rgba(79, 172, 254, 0.6);
        background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%);
    }

    .btn-secondary:hover {
        background: rgba(255, 255, 255, 0.25);
        border-color: rgba(255, 255, 255, 0.6);
        box-shadow: 0 25px 50px rgba(255, 255, 255, 0.2);
    }

    /* Right side with advanced 3D effects */
    .right {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        animation: slideInRight 1.2s cubic-bezier(0.4, 0, 0.2, 1) 0.4s both;
    }

    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(80px) translateY(-20px) rotateY(20deg);
        }
        to {
            opacity: 1;
            transform: translateX(0) translateY(0) rotateY(0deg);
        }
    }

    .image-container {
        position: relative;
        max-width: 550px;
        width: 100%;
        perspective: 1000px;
    }

    /* 3D rotating frame */
    .image-frame {
        position: relative;
        transform-style: preserve-3d;
        animation: rotate3d 30s linear infinite;
    }

    @keyframes rotate3d {
        from { transform: rotateY(0deg) rotateX(0deg); }
        to { transform: rotateY(360deg) rotateX(360deg); }
    }

    .image-frame::before {
        content: '';
        position: absolute;
        top: -30px;
        left: -30px;
        right: -30px;
        bottom: -30px;
        background: linear-gradient(45deg, 
            rgba(79, 172, 254, 0.3), 
            rgba(0, 242, 254, 0.3), 
            rgba(250, 112, 154, 0.3), 
            rgba(254, 225, 64, 0.3));
        border-radius: 30px;
        backdrop-filter: blur(20px);
        z-index: -1;
        animation: frame-glow 4s ease-in-out infinite;
    }

    @keyframes frame-glow {
        0%, 100% {
            box-shadow: 0 0 30px rgba(79, 172, 254, 0.4);
        }
        50% {
            box-shadow: 0 0 60px rgba(250, 112, 154, 0.6);
        }
    }

    .right img {
        width: 100%;
        height: auto;
        border-radius: 25px;
        position: relative;
        z-index: 1;
        filter: drop-shadow(0 30px 60px rgba(0, 0, 0, 0.4));
        animation: float-3d 8s ease-in-out infinite;
        transition: transform 0.3s ease;
    }

    @keyframes float-3d {
        0%, 100% { 
            transform: translateY(0px) rotateX(0deg) rotateY(0deg); 
        }
        25% { 
            transform: translateY(-20px) rotateX(5deg) rotateY(5deg); 
        }
        50% { 
            transform: translateY(0px) rotateX(0deg) rotateY(-5deg); 
        }
        75% { 
            transform: translateY(-15px) rotateX(-5deg) rotateY(0deg); 
        }
    }

    .right img:hover {
        transform: scale(1.05) rotateY(10deg) rotateX(-5deg);
    }

    /* Advanced decorative elements */
    .decoration-advanced {
        position: absolute;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0.05));
        backdrop-filter: blur(10px);
        animation: float-decoration-advanced 20s ease-in-out infinite;
    }

    .decoration-1 {
        width: 200px;
        height: 200px;
        top: 5%;
        right: 5%;
        animation-delay: 0s;
    }

    .decoration-2 {
        width: 150px;
        height: 150px;
        bottom: 10%;
        left: 0%;
        animation-delay: 7s;
    }

    .decoration-3 {
        width: 100px;
        height: 100px;
        top: 40%;
        left: -5%;
        animation-delay: 14s;
    }

    @keyframes float-decoration-advanced {
        0%, 100% { 
            transform: translate(0, 0) rotate(0deg) scale(1); 
            opacity: 0.3;
        }
        25% { 
            transform: translate(50px, -50px) rotate(90deg) scale(1.1); 
            opacity: 0.6;
        }
        50% { 
            transform: translate(0px, -80px) rotate(180deg) scale(0.9); 
            opacity: 0.4;
        }
        75% { 
            transform: translate(-30px, -20px) rotate(270deg) scale(1.05); 
            opacity: 0.5;
        }
    }

    /* Generate particles dynamically */
    .particles::before,
    .particles::after {
        content: '';
        position: absolute;
        width: 2px;
        height: 2px;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 50%;
        animation: particle-float 12s infinite linear;
    }

    .particles::before {
        top: 20%;
        left: 10%;
        animation-delay: 0s;
    }

    .particles::after {
        top: 60%;
        right: 15%;
        animation-delay: 6s;
        background: rgba(164, 176, 255, 0.7);
    }

    /* Responsive design improvements */
    @media (max-width: 1024px) {
        .container {
            gap: 60px;
        }
    }

    @media (max-width: 768px) {
        .container {
            flex-direction: column;
            text-align: center;
            gap: 50px;
            padding: 60px 20px;
        }

        .left {
            max-width: none;
        }

        .btn-group {
            max-width: none;
        }

        .right {
            order: -1;
        }

        .image-container {
            max-width: 400px;
        }

        .decoration-advanced {
            display: none;
        }

        .left h1 {
            font-size: clamp(2.2rem, 8vw, 3.5rem);
        }
    }

    @media (max-width: 480px) {
        .btn-group {
            gap: 16px;
        }

        .btn {
            padding: 16px 32px;
            font-size: 1rem;
        }

        .image-container {
            max-width: 300px;
        }
    }
</style>
<body>
    <!-- Advanced background animations -->
    <div class="bg-animation">
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>
        <div class="particles">
            <div class="particle" style="top: 10%; left: 20%; animation-delay: 0s;"></div>
            <div class="particle" style="top: 30%; left: 80%; animation-delay: 3s;"></div>
            <div class="particle" style="top: 70%; left: 30%; animation-delay: 6s;"></div>
            <div class="particle" style="top: 50%; left: 70%; animation-delay: 9s;"></div>
            <div class="particle" style="top: 20%; left: 60%; animation-delay: 12s;"></div>
        </div>
    </div>

    <!-- Advanced decorative elements -->
    <div class="decoration-advanced decoration-1"></div>
    <div class="decoration-advanced decoration-2"></div>
    <div class="decoration-advanced decoration-3"></div>
    
    <div class="container">
        <div class="left">
            <div class="badge">
                <i class="fas fa-rocket"></i>
                Arsip Digital v3.0 - Advanced
            </div>
            <h1>Sistem Informasi Arsip Digital</h1>
            <p>Revolusi pengelolaan arsip dengan teknologi AI terdepan. Akses file dengan kecepatan kilat, keamanan tingkat enterprise, dan interface yang memukau.</p>
            <div class="btn-group">
                <a href="login_user.php" class="btn btn-primary">
                    <i class="fas fa-user-circle"></i>
                    Login User
                </a>
                <a href="login_admin.php" class="btn btn-secondary">
                    <i class="fas fa-shield-alt"></i>
                    Login Admin / Petugas
                </a>
            </div>
        </div>
        <div class="right">
            <div class="image-container">
                <div class="image-frame">
                    <img src="img/foto.png" alt="Ilustrasi Arsip Digital Futuristik" loading="lazy">
                </div>
            </div>
        </div>
    </div>
</body>
</html>