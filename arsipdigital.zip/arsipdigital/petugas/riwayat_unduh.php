<?php 
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Petugas') {
    header("Location: ../login_admin.php");
    exit();
}

// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "arsipdigital";

$koneksi = new mysqli($host, $user, $pass, $db);
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Ambil data dari tabel riwayat unduh
$sql = "SELECT r.id_riwayat, u.nama_user, a.nama_arsip, r.waktu_unduh
        FROM riwayat_unduh r
        JOIN tb_user u ON r.id_user = u.id_user
        JOIN arsip a ON r.id_arsip = a.id
        ORDER BY r.waktu_unduh DESC";
$result = $koneksi->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Unduh - Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #ec4899 0%, #be185d 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(236, 72, 153, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #f472b6, #ec4899);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #fecaca;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #fecaca, #fbb6ce);
            color: #be185d;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(254, 202, 202, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #ffffff, #fef7ff);
            padding: 15px 30px;
            box-shadow: 0 2px 20px rgba(236, 72, 153, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(236, 72, 153, 0.1);
        }
        
        .welcome-text h1 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .welcome-text p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: linear-gradient(45deg, #ec4899, #be185d);
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .user-info img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-info .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .user-info .user-role {
            font-size: 0.75rem;
            opacity: 0.9;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .table-container {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .table-header h4 {
            color: #be185d;
            font-weight: 600;
            margin: 0;
        }
        
        .table-header .btn-refresh {
            background: linear-gradient(45deg, #ec4899, #be185d);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 8px 15px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .table-header .btn-refresh:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(236, 72, 153, 0.3);
        }
        
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            border-radius: 12px;
            overflow: hidden;
        }
        
        .table thead th {
            background: linear-gradient(45deg, #fdf2f8, #fce7f3);
            color: #be185d;
            font-weight: 600;
            padding: 15px;
            text-align: left;
            border-bottom: 2px solid rgba(244, 114, 182, 0.3);
        }
        
        .table tbody tr {
            transition: all 0.3s ease;
        }
        
        .table tbody tr:hover {
            background-color: rgba(252, 231, 243, 0.5);
            transform: scale(1.01);
        }
        
        .table tbody td {
            padding: 15px;
            border-bottom: 1px solid rgba(244, 114, 182, 0.2);
            color: #9f1239;
        }
        
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.8rem;
        }
        
        .badge-success {
            background: linear-gradient(45deg, #a7f3d0, #6ee7b7);
            color: #065f46;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #ec4899;
        }
        
        .no-data i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .table-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .table thead {
                display: none;
            }
            
            .table tbody tr {
                display: block;
                margin-bottom: 20px;
                border-radius: 12px;
                box-shadow: 0 4px 15px rgba(236, 72, 153, 0.1);
                background: white;
            }
            
            .table tbody td {
                display: block;
                text-align: right;
                padding: 10px 15px;
                position: relative;
                border-bottom: 1px solid rgba(244, 114, 182, 0.1);
            }
            
            .table tbody td::before {
                content: attr(data-label);
                position: absolute;
                left: 15px;
                font-weight: 600;
                color: #be185d;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php">
            <i class="fas fa-folder-open"></i>
            Data Arsip
        </a>
        <a href="data_kategori.php">
            <i class="fas fa-tags"></i>
            Data Kategori
        </a>
        <a href="data_user.php">
            <i class="fas fa-users"></i>
            Data User
        </a>
        <a href="riwayat_unduh.php" class="active">
            <i class="fas fa-download"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="welcome-text">
            <h1>Riwayat Unduh</h1>
            <p>Data riwayat pengunduhan arsip digital</p>
        </div>
        
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=ec4899&color=fff" alt="User">
            <div class="user-details">
                <div class="user-name"><?php echo $_SESSION['username']; ?></div>
                <div class="user-role"><?php echo $_SESSION['role']; ?></div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Riwayat Unduh</span>
        </div>
        
        <!-- Table Container -->
        <div class="table-container">
            <div class="table-header">
                <h4><i class="fas fa-download me-2"></i>Data Riwayat Unduh Arsip</h4>
                <button class="btn-refresh" onclick="window.location.reload()">
                    <i class="fas fa-sync-alt me-1"></i>Refresh
                </button>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Waktu Unduh</th>
                            <th>User</th>
                            <th>Arsip yang Diunduh</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td data-label='No'>{$no}</td>
                                        <td data-label='Waktu Unduh'>{$row['waktu_unduh']}</td>
                                        <td data-label='User'>{$row['nama_user']}</td>
                                        <td data-label='Arsip'>{$row['nama_arsip']}</td>
                                      </tr>";
                                $no++;
                            }
                        } else {
                            echo "<tr>
                                    <td colspan='4'>
                                        <div class='no-data'>
                                            <i class='fas fa-inbox'></i>
                                            <p>Tidak ada data riwayat unduh</p>
                                        </div>
                                    </td>
                                  </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Add some interactive effects
document.querySelectorAll('.table tbody tr').forEach(row => {
    row.addEventListener('mouseenter', function() {
        this.style.transform = 'translateX(5px)';
        this.style.boxShadow = '0 5px 15px rgba(236, 72, 153, 0.2)';
    });
    
    row.addEventListener('mouseleave', function() {
        this.style.transform = 'translateX(0)';
        this.style.boxShadow = 'none';
    });
});
</script>
</body>
</html>