<?php
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Petugas') {
    header("Location: ../login_admin.php");
    exit();
}

$username = $_SESSION['username'];
$pesan = "";

/* -----------------------------
   1. MIGRASI PASSWORD OTOMATIS
------------------------------*/
$result = mysqli_query($koneksi, "SELECT id_petugas, username, password FROM petugas");

while ($row = mysqli_fetch_assoc($result)) {
    $id_petugas = $row['id_petugas'];
    $password   = $row['password'];

    // Cek apakah password sudah hash atau masih plain text
    if (strlen($password) < 60 || substr($password, 0, 4) !== '$2y$') {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        mysqli_query($koneksi, "UPDATE petugas SET password='$hash' WHERE id_petugas='$id_petugas'");
    }
}

/* -----------------------------
   2. PROSES GANTI PASSWORD
------------------------------*/
if (isset($_POST['simpan'])) {
    $password_lama   = mysqli_real_escape_string($koneksi, $_POST['password_lama']);
    $password_baru   = mysqli_real_escape_string($koneksi, $_POST['password_baru']);
    $konfirmasi_baru = mysqli_real_escape_string($koneksi, $_POST['konfirmasi_baru']);

    // Ambil password lama dari database
    $query = mysqli_query($koneksi, "SELECT password FROM petugas WHERE username='$username'");
    $data  = mysqli_fetch_assoc($query);

    if ($data) {
        // Verifikasi password lama
        if (password_verify($password_lama, $data['password']) || $password_lama === $data['password']) {
            // Cek konfirmasi password baru
            if ($password_baru === $konfirmasi_baru) {
                $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);
                $update = mysqli_query($koneksi, "UPDATE petugas SET password='$password_hash' WHERE username='$username'");

                if ($update) {
                    $pesan = "<div class='alert alert-success'>Password berhasil diubah!</div>";
                } else {
                    $pesan = "<div class='alert alert-danger'>Terjadi kesalahan, password gagal diubah.</div>";
                }
            } else {
                $pesan = "<div class='alert alert-warning'>Konfirmasi password baru tidak sama!</div>";
            }
        } else {
            $pesan = "<div class='alert alert-danger'>Password lama salah!</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password - Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #ec4899 0%, #be185d 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(236, 72, 153, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #f472b6, #ec4899);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #fecaca;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #fecaca, #fbb6ce);
            color: #be185d;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(254, 202, 202, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #ffffff, #fef7ff);
            padding: 15px 30px;
            box-shadow: 0 2px 20px rgba(236, 72, 153, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(236, 72, 153, 0.1);
        }
        
        .welcome-text h1 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .welcome-text p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: linear-gradient(45deg, #ec4899, #be185d);
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .user-info img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-info .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .user-info .user-role {
            font-size: 0.75rem;
            opacity: 0.9;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .password-card {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(244, 114, 182, 0.2);
            max-width: 600px;
            margin: 0 auto;
        }
        
        .password-card h4 {
            color: #be185d;
            margin-bottom: 25px;
            font-weight: 600;
            text-align: center;
        }
        
        .form-label {
            color: #be185d;
            font-weight: 500;
        }
        
        .form-control {
            border: 1px solid rgba(244, 114, 182, 0.3);
            border-radius: 12px;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: #ec4899;
            box-shadow: 0 0 0 0.25rem rgba(236, 72, 153, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(45deg, #ec4899, #be185d);
            border: none;
            border-radius: 12px;
            padding: 12px 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(236, 72, 153, 0.4);
        }
        
        .alert {
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            border: none;
        }
        
        .alert-success {
            background: linear-gradient(45deg, #a7f3d0, #6ee7b7);
            color: #065f46;
        }
        
        .alert-danger {
            background: linear-gradient(45deg, #fecaca, #fca5a5);
            color: #7f1d1d;
        }
        
        .alert-warning {
            background: linear-gradient(45deg, #fef3c7, #fde68a);
            color: #92400e;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .password-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php">
            <i class="fas fa-folder-open"></i>
            Data Arsip
        </a>
        <a href="data_kategori.php">
            <i class="fas fa-tags"></i>
            Data Kategori
        </a>
        <a href="data_user.php">
            <i class="fas fa-users"></i>
            Data User
        </a>
        <a href="riwayat_unduh.php">
            <i class="fas fa-download"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php" class="active">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="welcome-text">
            <h1>Ganti Password</h1>
            <p>Ubah password akun Anda</p>
        </div>
        
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=ec4899&color=fff" alt="User">
            <div class="user-details">
                <div class="user-name"><?php echo $_SESSION['username']; ?></div>
                <div class="user-role"><?php echo $_SESSION['role']; ?></div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Ganti Password</span>
        </div>
        
        <!-- Password Card -->
        <div class="password-card">
            <h4><i class="fas fa-key me-2"></i>Ganti Password</h4>
            <?php echo $pesan; ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="password_lama" class="form-label">Password Lama</label>
                    <input type="password" class="form-control" id="password_lama" name="password_lama" required>
                </div>
                <div class="mb-3">
                    <label for="password_baru" class="form-label">Password Baru</label>
                    <input type="password" class="form-control" id="password_baru" name="password_baru" required>
                </div>
                <div class="mb-3">
                    <label for="konfirmasi_baru" class="form-label">Konfirmasi Password Baru</label>
                    <input type="password" class="form-control" id="konfirmasi_baru" name="konfirmasi_baru" required>
                </div>
                <button type="submit" name="simpan" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i>Simpan Perubahan
                </button>
            </form>
        </div>
    </div>
</div>

<script>
// Add some interactive effects
document.querySelectorAll('.form-control').forEach(input => {
    input.addEventListener('focus', function() {
        this.style.transform = 'scale(1.02)';
        this.style.boxShadow = '0 5px 15px rgba(236, 72, 153, 0.2)';
    });
    
    input.addEventListener('blur', function() {
        this.style.transform = 'scale(1)';
        this.style.boxShadow = 'none';
    });
});
</script>
</body>
</html>