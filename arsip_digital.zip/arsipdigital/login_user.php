<?php
// login_user.php
session_start();
include 'config/koneksi.php';

$pesan = "";
$show_register_prompt = false;

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Cek apakah username exists di database
    $query = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$username'");
    $data  = mysqli_fetch_assoc($query);

    if ($data) {
        // Username ditemukan, cek password
        if (password_verify($password, $data['password']) || $password === $data['password']) {
            $_SESSION['id_user']  = $data['id_user'];
            $_SESSION['username'] = $data['username'];
            $_SESSION['nama_user'] = $data['nama_user'];
            $_SESSION['role']     = "User";

            header("Location: user/dashboard.php");
            exit;
        } else {
            $pesan = "<div class='alert-error'>Password salah!</div>";
        }
    } else {
        // Username tidak ditemukan - tampilkan pesan untuk registrasi
        $pesan = "<div class='alert-error'>Username tidak ditemukan!</div>";
        $show_register_prompt = true;
    }
}

// Cek apakah ada pesan sukses registrasi
if (isset($_SESSION['registration_success'])) {
    $pesan = "<div class='alert-success'>" . $_SESSION['registration_success'] . "</div>";
    unset($_SESSION['registration_success']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login User | Sistem Informasi Arsip Digital</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 25%, #334155 50%, #475569 75%, #64748b 100%);
        min-height: 100vh;
        position: relative;
        overflow-x: hidden;
    }

    /* Animated background elements */
    body::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-image: 
            radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(147, 197, 253, 0.15) 0%, transparent 50%),
            radial-gradient(circle at 40% 80%, rgba(96, 165, 250, 0.1) 0%, transparent 50%);
        animation: float 20s ease-in-out infinite;
    }

    @keyframes float {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(1deg); }
    }

    .login-page {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        padding: 20px;
        position: relative;
        z-index: 1;
    }

    .login-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        padding: 50px 40px;
        width: 100%;
        max-width: 450px;
        border-radius: 24px;
        box-shadow: 
            0 25px 50px rgba(0, 0, 0, 0.15),
            0 0 0 1px rgba(255, 255, 255, 0.1) inset;
        position: relative;
        animation: slideUp 0.8s ease-out;
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .login-container::before {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: linear-gradient(135deg, #3b82f6, #1d4ed8, #2563eb, #60a5fa);
        border-radius: 26px;
        z-index: -1;
        opacity: 0.1;
    }

    .header {
        text-align: center;
        margin-bottom: 40px;
    }

    .logo {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #3b82f6, #1d4ed8);
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }

    .logo i {
        color: white;
        font-size: 36px;
    }

    .header h1 {
        font-size: 28px;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 8px;
        background: linear-gradient(135deg, #1e293b, #475569);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .header p {
        color: #64748b;
        font-size: 16px;
        font-weight: 400;
    }

    .form-title {
        text-align: center;
        margin-bottom: 30px;
        color: #1e293b;
        font-size: 20px;
        font-weight: 600;
        position: relative;
    }

    .form-title::after {
        content: '';
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        width: 60px;
        height: 3px;
        background: linear-gradient(135deg, #3b82f6, #1d4ed8);
        border-radius: 2px;
    }

    .form-group {
        margin-bottom: 24px;
        position: relative;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        font-weight: 500;
        color: #374151;
    }

    .input-wrapper {
        position: relative;
    }

    .input-wrapper i {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #9ca3af;
        transition: color 0.3s ease;
        z-index: 2;
    }

    .form-group input {
        width: 100%;
        padding: 16px 16px 16px 50px;
        border: 2px solid #e5e7eb;
        border-radius: 12px;
        font-size: 16px;
        background: rgba(255, 255, 255, 0.8);
        transition: all 0.3s ease;
        position: relative;
    }

    .form-group input:focus {
        outline: none;
        border-color: #3b82f6;
        background: white;
        box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
    }

    .form-group input:focus + .input-wrapper i {
        color: #3b82f6;
    }

    .btn-primary {
        width: 100%;
        padding: 16px;
        background: linear-gradient(135deg, #3b82f6, #1d4ed8);
        border: none;
        color: white;
        font-size: 16px;
        font-weight: 600;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        margin-bottom: 24px;
    }

    .btn-primary::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left 0.5s;
    }

    .btn-primary:hover::before {
        left: 100%;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(59, 130, 246, 0.4);
    }

    .btn-primary:active {
        transform: translateY(0);
    }

    .action-buttons {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }

    .btn-secondary, .btn-success {
        flex: 1;
        min-width: 140px;
        padding: 12px 20px;
        border: none;
        color: white;
        font-size: 14px;
        font-weight: 500;
        border-radius: 10px;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all 0.3s ease;
    }

    .btn-secondary {
        background: linear-gradient(135deg, #6b7280, #4b5563);
    }

    .btn-secondary:hover {
        background: linear-gradient(135deg, #4b5563, #374151);
        transform: translateY(-2px);
    }

    .btn-success {
        background: linear-gradient(135deg, #10b981, #059669);
    }

    .btn-success:hover {
        background: linear-gradient(135deg, #059669, #047857);
        transform: translateY(-2px);
    }

    .alert-error, .alert-success {
        padding: 16px;
        border-radius: 12px;
        margin-bottom: 20px;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideDown 0.5s ease-out;
    }

    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .alert-error {
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.2);
        color: #dc2626;
    }

    .alert-success {
        background: rgba(16, 185, 129, 0.1);
        border: 1px solid rgba(16, 185, 129, 0.2);
        color: #059669;
    }

    .register-prompt {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 197, 253, 0.1));
        border: 1px solid rgba(59, 130, 246, 0.2);
        border-radius: 12px;
        padding: 20px;
        margin: 20px 0;
        color: #1e40af;
        text-align: center;
    }

    .register-prompt strong {
        display: block;
        margin-bottom: 10px;
        font-size: 16px;
        color: #1d4ed8;
    }

    /* Responsive Design */
    @media (max-width: 480px) {
        .login-container {
            padding: 30px 20px;
        }

        .action-buttons {
            flex-direction: column;
        }

        .btn-secondary, .btn-success {
            min-width: 100%;
        }
    }

    /* Dark mode support */
    @media (prefers-color-scheme: dark) {
        .login-container {
            background: rgba(30, 41, 59, 0.95);
            color: white;
        }

        .header h1 {
            color: white;
        }

        .form-title {
            color: white;
        }

        .form-group label {
            color: #e2e8f0;
        }

        .form-group input {
            background: rgba(51, 65, 85, 0.8);
            border-color: #475569;
            color: white;
        }

        .form-group input::placeholder {
            color: #94a3b8;
        }
    }
</style>
<body class="login-page">
    <div class="login-container">
        <div class="header">
            <div class="logo">
                <i class="fas fa-archive"></i>
            </div>
            <h1>Sistem Informasi<br>Arsip Digital</h1>
            <p>Silahkan login untuk mengakses arsip</p>
        </div>
        
        <?php echo $pesan; ?>
        
        <?php if ($show_register_prompt): ?>
        <div class="register-prompt">
            <strong><i class="fas fa-info-circle"></i> Belum memiliki akun?</strong>
            Silakan daftar terlebih dahulu untuk membuat akun baru, kemudian login dengan akun yang telah dibuat.
        </div>
        <?php endif; ?>
        
        <form method="post">
            <h3 class="form-title">Login User</h3>
            
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" required placeholder="Masukkan username">
                </div>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" required placeholder="Masukkan password">
                </div>
            </div>

            <button type="submit" name="login" class="btn-primary">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
            
            <div class="action-buttons">
                <a href="register.php" class="btn-success">
                    <i class="fas fa-user-plus"></i> Daftar Akun
                </a>
                <a href="index.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</body>
</html>