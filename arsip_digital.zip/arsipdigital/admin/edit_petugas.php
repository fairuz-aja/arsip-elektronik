<?php
session_start();
include '../config/koneksi.php';

// Cek login admin
if (!isset($_SESSION['username'])) {
    header("Location: ../login_admin.php");
    exit();
}

// Ambil id petugas dari URL
$id_petugas = $_GET['id'] ?? '';

if (!$id_petugas) {
    header("Location: data_petugas.php");
    exit;
}

// Ambil data petugas
$sql = "SELECT * FROM tb_petugas WHERE id_petugas = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id_petugas);
$stmt->execute();
$result = $stmt->get_result();
$petugas = $result->fetch_assoc();

if (!$petugas) {
    echo "Petugas tidak ditemukan!";
    exit;
}

// Jika form disubmit
if (isset($_POST['submit'])) {
    $nama_petugas = $_POST['nama_petugas'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Update data petugas
    if ($nama_petugas != '' && $username != '') {
        if ($password != '') {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $update = "UPDATE tb_petugas SET nama_petugas=?, username=?, password=? WHERE id_petugas=?";
            $stmt = $koneksi->prepare($update);
            $stmt->bind_param("sssi", $nama, $username, $password_hash, $id_petugas);
        } else {
            $update = "UPDATE tb_petugas SET nama_petugas=?, username=? WHERE id_petugas=?";
            $stmt = $koneksi->prepare($update);
            $stmt->bind_param("ssi", $nama_petugas, $username, $id_petugas);
        }
        $stmt->execute();
        header("Location: data_petugas.php");
        exit;
    } else {
        $error = "Nama dan Username tidak boleh kosong!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Petugas - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .form-container {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      margin-bottom: 30px;
      border: 1px solid rgba(200, 168, 255, 0.2);
    }
    
    .form-header {
      margin-bottom: 25px;
      padding-bottom: 15px;
      border-bottom: 1px solid rgba(139, 93, 255, 0.2);
    }
    
    .form-header h4 {
      color: #6B46C1;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-group label {
      color: #6B46C1;
      font-weight: 500;
      margin-bottom: 8px;
    }
    
    .form-control {
      border: 1px solid rgba(139, 93, 255, 0.3);
      border-radius: 12px;
      padding: 12px 15px;
      transition: all 0.3s ease;
    }
    
    .form-control:focus {
      border-color: #8B5DFF;
      box-shadow: 0 0 0 0.25rem rgba(139, 93, 255, 0.25);
    }
    
    .btn-primary {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 12px;
      padding: 12px 25px;
      font-weight: 500;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
      background: linear-gradient(45deg, #7C4DFF, #8B5DFF);
    }
    
    .btn-secondary {
      background: linear-gradient(45deg, #A0AEC0, #718096);
      border: none;
      border-radius: 12px;
      padding: 12px 25px;
      font-weight: 500;
      box-shadow: 0 4px 15px rgba(160, 174, 192, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-secondary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(160, 174, 192, 0.4);
      background: linear-gradient(45deg, #718096, #A0AEC0);
    }
    
    .alert-danger {
      background: linear-gradient(45deg, #FECACA, #FCA5A5);
      border: none;
      border-radius: 12px;
      color: #7F1D1D;
      padding: 15px;
      margin-bottom: 20px;
      box-shadow: 0 4px 15px rgba(254, 202, 202, 0.3);
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .main-content {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php" class="active">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Edit Petugas - Sistem Informasi Arsip Digital</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="#"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Form Edit Petugas -->
    <div class="form-container">
      <div class="form-header">
        <h4><i class="fas fa-user-edit"></i> Edit Data Petugas</h4>
      </div>
      
      <?php if(isset($error)): ?>
        <div class="alert alert-danger">
          <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
        </div>
      <?php endif; ?>
      
      <form method="POST">
        <div class="form-group">
          <label for="nama_petugas">Nama Petugas</label>
          <input type="text" name="nama_petugas" id="nama_petugas" class="form-control" value="<?= htmlspecialchars($petugas['nama_petugas']); ?>" required>
        </div>
        
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" name="username" id="username" class="form-control" value="<?= htmlspecialchars($petugas['username']); ?>" required>
        </div>
        
        <div class="form-group">
          <label for="password">Password (kosongkan jika tidak ingin diganti)</label>
          <input type="password" name="password" id="password" class="form-control">
          <small class="text-muted">Minimal 6 karakter</small>
        </div>
        
        <button type="submit" name="submit" class="btn btn-primary">
          <i class="fas fa-save me-2"></i>Update Data
        </button>
        <a href="data_petugas.php" class="btn btn-secondary">
          <i class="fas fa-arrow-left me-2"></i>Kembali
        </a>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>