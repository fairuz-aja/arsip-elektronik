<?php
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: ../login_admin.php");
    exit();
}

// Ambil data arsip dengan relasi kategori & petugas
$query = mysqli_query($koneksi, "SELECT a.id, a.kode_arsip, a.nama_arsip, a.keterangan, a.file_path, 
       a.tanggal_upload, a.waktu_upload,
       k.nama_kategori, 
       p.nama_petugas
FROM arsip a
LEFT JOIN tb_kategori k ON a.id_kategori = k.id_kategori
LEFT JOIN tb_petugas p ON a.id_petugas = p.id_petugas;
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Arsip - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .data-card {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      padding: 25px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      position: relative;
      overflow: hidden;
      border: 1px solid rgba(200, 168, 255, 0.2);
      margin-bottom: 30px;
    }
    
    .data-card-header {
      padding-bottom: 15px;
      margin-bottom: 20px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .data-card-header h4 {
      color: #6B46C1;
      font-weight: 600;
      margin: 0;
    }
    
    .table-container {
      overflow-x: auto;
    }
    
    .table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .table th {
      background: linear-gradient(45deg, #f3e8ff, #e9d5ff);
      color: #6B46C1;
      font-weight: 600;
      padding: 12px 15px;
      text-align: left;
      border-bottom: 2px solid rgba(200, 168, 255, 0.3);
    }
    
    .table td {
      padding: 12px 15px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      vertical-align: top;
    }
    
    .table tr:hover {
      background-color: rgba(200, 168, 255, 0.1);
    }
    
    .btn-action {
      padding: 8px 12px;
      border-radius: 10px;
      font-size: 0.85rem;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-right: 8px;
      margin-bottom: 5px;
      transition: all 0.3s ease;
      box-shadow: 0 3px 8px rgba(0,0,0,0.1);
      border: none;
      position: relative;
      overflow: hidden;
    }
    
    .btn-action::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
      transition: all 0.5s ease;
    }
    
    .btn-action:hover::before {
      left: 100%;
    }
    
    .btn-download {
      background: linear-gradient(45deg, #10B981, #34D399);
      color: white;
    }
    
    .btn-preview {
      background: linear-gradient(45deg, #3B82F6, #60A5FA);
      color: white;
    }
    
    .btn-edit {
      background: linear-gradient(45deg, #F59E0B, #FBBF24);
      color: white;
    }
    
    .btn-delete {
      background: linear-gradient(45deg, #EF4444, #F87171);
      color: white;
    }
    
    .btn-action:hover {
      transform: translateY(-3px) scale(1.05);
      box-shadow: 0 6px 15px rgba(0,0,0,0.2);
    }
    
    .badge-category {
      background: linear-gradient(45deg, #8B5DFF, #C8A8FF);
      color: white;
      padding: 4px 10px;
      border-radius: 15px;
      font-size: 0.8rem;
    }
    
    .badge-petugas {
      background: linear-gradient(45deg, #A855F7, #C084FC);
      color: white;
      padding: 4px 10px;
      border-radius: 15px;
      font-size: 0.8rem;
    }
    
    .info-section {
      background: linear-gradient(135deg, #8B5DFF, #A855F7);
      border-radius: 20px;
      padding: 25px;
      color: white;
      text-align: center;
      margin-top: 30px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.3);
    }
    
    .info-section h4 {
      margin-bottom: 10px;
    }
    
    .info-section p {
      opacity: 0.9;
      margin: 0;
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .main-content {
        padding: 20px;
      }
      
      .btn-action {
        padding: 6px 10px;
        font-size: 0.75rem;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php" class="active">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Data Arsip - Sistem Informasi Arsip Digital</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="#"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Data Card -->
    <div class="data-card">
      <div class="data-card-header">
        <h4><i class="fas fa-folder-open me-2"></i>Daftar Arsip Digital</h4>
      </div>
      
      <div class="table-container">
        <table id="tabelArsip" class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Waktu Upload</th>
              <th>Arsip</th>
              <th>Kategori</th>
              <th>Petugas</th>
              <th>Keterangan</th>
              <th>Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1;
            while($row = mysqli_fetch_assoc($query)): 
            ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= date('H:i:s d-m-Y', strtotime($row['waktu_upload'])); ?></td>
              <td>
                <div><b>KODE :</b> <?= htmlspecialchars($row['kode_arsip']); ?></div>
                <div><b>Nama :</b> <?= htmlspecialchars($row['nama_arsip']); ?></div>
              </td>
              <td><span class="badge-category"><?= htmlspecialchars($row['nama_kategori']); ?></span></td>
              <td><span class="badge-petugas"><?= htmlspecialchars($row['nama_petugas']); ?></span></td>
              <td><?= htmlspecialchars($row['keterangan']); ?></td>
              <td>
                <div class="d-flex flex-wrap">
                  <a href="../download_arsip.php?id=<?= $row['id']; ?>" class="btn-action btn-download">
                    <i class="fas fa-file-download"></i> Unduh
                  </a>
                  <a href="../preview_arsip.php?id=<?= $row['id']; ?>" target="_blank" class="btn-action btn-preview">
                    <i class="fas fa-eye"></i> Lihat
                  </a>
                  <a href="edit_arsip.php?id=<?= $row['id']; ?>" class="btn-action btn-edit">
                    <i class="fas fa-edit"></i> Edit
                  </a>
                  <a href="hapus_arsip.php?id=<?= $row['id']; ?>" 
                     onclick="return confirm('Yakin hapus arsip ini?');"
                     class="btn-action btn-delete">
                    <i class="fas fa-trash-alt"></i> Hapus
                  </a>
                </div>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
  $(document).ready(function () {
    $('#tabelArsip').DataTable({
      language: {
        search: "Cari:",
        lengthMenu: "Tampilkan _MENU_ data per halaman",
        info: "Menampilkan _START_ hingga _END_ dari _TOTAL_ arsip",
        infoEmpty: "Menampilkan 0 hingga 0 dari 0 arsip",
        paginate: {
          first: "Pertama",
          last: "Terakhir",
          next: "Selanjutnya",
          previous: "Sebelumnya"
        }
      }
    });
    
    // Add some interactive effects
    document.querySelectorAll('.btn-action').forEach(btn => {
      btn.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-3px) scale(1.05)';
        this.style.boxShadow = '0 6px 15px rgba(0,0,0,0.2)';
      });
      
      btn.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = 'none';
      });
    });
  });
</script>
</body>
</html>