<?php
session_start();
include '../config/koneksi.php';

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: ../login_admin.php");
    exit();
}

$query = mysqli_query($koneksi, "SELECT r.*, u.nama_lengkap AS nama_user, a.nama_arsip, a.file_path AS file_arsip 
FROM riwayat_unduh r 
LEFT JOIN tb_user u ON r.id_user = u.id_user 
LEFT JOIN arsip a ON r.id_arsip = a.id 
ORDER BY r.id_riwayat DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Riwayat Unduh - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .data-card {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      padding: 25px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      position: relative;
      overflow: hidden;
      border: 1px solid rgba(200, 168, 255, 0.2);
      margin-bottom: 30px;
    }
    
    .data-card-header {
      padding-bottom: 15px;
      margin-bottom: 20px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .data-card-header h4 {
      color: #6B46C1;
      font-weight: 600;
      margin: 0;
    }
    
    .table-container {
      overflow-x: auto;
    }
    
    .table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .table thead th {
      background: linear-gradient(45deg, #faf7ff, #f3e8ff);
      color: #6B46C1;
      font-weight: 600;
      padding: 12px 15px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.3);
    }
    
    .table tbody tr {
      transition: all 0.3s ease;
    }
    
    .table tbody tr:hover {
      background-color: rgba(200, 168, 255, 0.1);
    }
    
    .table tbody td {
      padding: 12px 15px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      color: #4C1D95;
    }
    
    .badge {
      padding: 6px 12px;
      border-radius: 20px;
      font-weight: 500;
    }
    
    .badge-success {
      background: linear-gradient(45deg, #10B981, #34D399);
      color: white;
    }
    
    .file-link {
      color: #8B5DFF;
      text-decoration: none;
      transition: all 0.3s ease;
      font-weight: 500;
    }
    
    .file-link:hover {
      color: #6B46C1;
      text-decoration: underline;
    }
    
    .info-section {
      background: linear-gradient(135deg, #8B5DFF, #A855F7);
      border-radius: 20px;
      padding: 25px;
      color: white;
      text-align: center;
      margin-top: 30px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.3);
    }
    
    .info-section h4 {
      margin-bottom: 10px;
    }
    
    .info-section p {
      opacity: 0.9;
      margin: 0;
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .main-content {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php" class="active">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Riwayat Unduh Arsip</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="#"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <!-- Data Card -->
    <div class="data-card">
      <div class="data-card-header">
        <h4><i class="fas fa-download me-2"></i>Data Riwayat Unduhan Arsip</h4>
      </div>
      <div class="table-container">
        <table id="tabelRiwayat" class="table table-hover">
          <thead>
            <tr>
              <th>No</th>
              <th>Waktu Unduh</th>
              <th>User</th>
              <th>Arsip yang diunduh</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1;
            while($row = mysqli_fetch_assoc($query)){ ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= date('H:i:s d-m-Y', strtotime($row['waktu_unduh'])); ?></td>
                <td><?= htmlspecialchars($row['nama_user']); ?></td>
                <td>
                  <a class="file-link" href="../uploads/<?= $row['file_arsip']; ?>" target="_blank">
                    <i class="fas fa-file-download me-1"></i>
                    <?= htmlspecialchars($row['nama_arsip']); ?>
                  </a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Info Section -->
    <div class="info-section">
      <h4><i class="fas fa-history me-2"></i>Riwayat Unduhan</h4>
      <p>Semua aktivitas pengunduhan arsip tercatat dengan rapi di sistem</p>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
  $(document).ready(function () {
    $('#tabelRiwayat').DataTable({
      language: {
        search: "Cari:",
        lengthMenu: "Tampilkan _MENU_ data per halaman",
        info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
        infoEmpty: "Menampilkan 0 sampai 0 dari 0 data",
        infoFiltered: "(disaring dari _MAX_ total data)",
        paginate: {
          first: "Pertama",
          last: "Terakhir",
          next: "Selanjutnya",
          previous: "Sebelumnya"
        }
      },
      responsive: true
    });
  });
</script>
</body>
</html>