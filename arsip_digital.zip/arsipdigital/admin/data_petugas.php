<?php
session_start();
include '../config/koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: ../login_admin.php");
    exit();
}

// Ambil data petugas dari database
$query = mysqli_query($koneksi, "SELECT * FROM tb_petugas ORDER BY id_petugas ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Petugas - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .card {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      overflow: hidden;
      border: 1px solid rgba(200, 168, 255, 0.2);
    }
    
    .card-header {
      background: linear-gradient(45deg, #faf7ff, #f3e8ff);
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      padding: 20px 25px;
      color: #6B46C1;
      font-weight: 600;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .btn-primary {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
      background: linear-gradient(45deg, #7C4DFF, #6A4C93);
    }
    
    .btn-warning {
      background: linear-gradient(45deg, #F59E0B, #D97706);
      border: none;
      border-radius: 25px;
      box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-danger {
      background: linear-gradient(45deg, #EF4444, #DC2626);
      border: none;
      border-radius: 25px;
      box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-sm {
      padding: 5px 12px;
      font-size: 0.875rem;
    }
    
    .table {
      border-collapse: separate;
      border-spacing: 0;
      width: 100%;
    }
    
    .table thead th {
      background: linear-gradient(45deg, #8B5DFF, #A855F7);
      color: white;
      border: none;
      padding: 12px 15px;
      font-weight: 600;
    }
    
    .table tbody tr {
      transition: all 0.3s ease;
    }
    
    .table tbody tr:hover {
      background-color: rgba(139, 93, 255, 0.1);
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(139, 93, 255, 0.1);
    }
    
    .table tbody td {
      padding: 12px 15px;
      vertical-align: middle;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
    }
    
    .rounded-circle {
      border: 2px solid rgba(139, 93, 255, 0.3);
      box-shadow: 0 2px 8px rgba(139, 93, 255, 0.2);
    }
    
    .dataTables_wrapper .dataTables_paginate .paginate_button {
      border-radius: 20px !important;
      margin: 0 3px;
      border: 1px solid rgba(139, 93, 255, 0.3) !important;
    }
    
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF) !important;
      color: white !important;
      border: none !important;
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .main-content {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php" class="active">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Data Petugas</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="#"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="card">
      <div class="card-header">
        <span>Daftar Petugas</span>
        <a href="tambah_petugas.php" class="btn btn-primary btn-sm">
          <i class="fa fa-plus"></i> Tambah Petugas
        </a>
      </div>
      <div class="card-body">
        <table id="tabelPetugas" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>No</th>
              <th>Foto</th>
              <th>Nama</th>
              <th>Username</th>
              <th>Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1;
            while($row = mysqli_fetch_assoc($query)){ ?>
              <tr>
                <td><?= $no++; ?></td>
                <td>
                  <?php if(!empty($row['foto'])){ ?>
                    <img src="../uploads/<?= $row['foto']; ?>" width="40" height="40" class="rounded-circle">
                  <?php } else { ?>
                    <img src="../assets/img/default.png" width="40" height="40" class="rounded-circle">
                  <?php } ?>
                </td>
                <td><?= htmlspecialchars($row['nama_petugas']); ?></td>
                <td><?= htmlspecialchars($row['username']); ?></td>
                <td>
                  <a href="edit_petugas.php?id=<?= $row['id_petugas']; ?>" class="btn btn-warning btn-sm">
                    <i class="fa fa-pen"></i>
                  </a>
                  <a href="hapus_petugas.php?id=<?= $row['id_petugas']; ?>" 
                     onclick="return confirm('Yakin hapus petugas ini?');"
                     class="btn btn-danger btn-sm">
                    <i class="fa fa-trash"></i>
                  </a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
  $(document).ready(function () {
    $('#tabelPetugas').DataTable({
      language: {
        search: "Cari:",
        lengthMenu: "Tampilkan _MENU_ data per halaman",
        info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
        infoEmpty: "Menampilkan 0 sampai 0 dari 0 data",
        infoFiltered: "(disaring dari _MAX_ total data)",
        paginate: {
          first: "Pertama",
          last: "Terakhir",
          next: "Selanjutnya",
          previous: "Sebelumnya"
        }
      }
    });
  });
</script>
</body>
</html>