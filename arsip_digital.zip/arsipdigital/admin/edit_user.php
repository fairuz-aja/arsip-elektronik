<?php
include '../config/koneksi.php';
session_start();

// Cek apakah ada parameter ID
if (!isset($_GET['id'])) {
    header("Location: data_user.php");
    exit();
}

$id_user = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE id_user='$id_user'");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "Data user tidak ditemukan!";
    exit();
}

// Proses update jika form disubmit
if (isset($_POST['update'])) {
    $nama_user = mysqli_real_escape_string($koneksi, $_POST['nama_user']);
    $username  = mysqli_real_escape_string($koneksi, $_POST['username']);

    // Cek apakah upload foto baru
    $foto = $data['foto']; 
    if (!empty($_FILES['foto']['name'])) {
        $target_dir = "../foto/";
        $foto = time() . "_" . basename($_FILES["foto"]["name"]);
        $target_file = $target_dir . $foto;
        move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file);
    }

    $update = mysqli_query($koneksi, "UPDATE tb_user SET 
                                        nama_user='$nama_user',
                                        username='$username',
                                        foto='$foto'
                                      WHERE id_user='$id_user'");
    if ($update) {
        echo "<script>alert('Data user berhasil diperbarui!');window.location='data_user.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit User - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }
    
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #8B5DFF 0%, #6A4C93 100%);
      color: white;
      padding: 0;
      z-index: 1000;
      overflow-y: auto;
      box-shadow: 2px 0 15px rgba(139, 93, 255, 0.3);
    }
    
    .sidebar-header {
      padding: 20px;
      text-align: center;
      background: linear-gradient(45deg, #9D6BFF, #7C4DFF);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-header h4 {
      color: #ffffff;
      font-weight: bold;
      margin: 0;
      font-size: 1.4rem;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sidebar-header .subtitle {
      font-size: 0.8rem;
      color: rgba(255,255,255,0.8);
      margin-top: 5px;
    }
    
    .sidebar-menu {
      padding: 20px 0;
    }
    
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: rgba(255,255,255,0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
      position: relative;
    }
    
    .sidebar-menu a:hover {
      background: rgba(255,255,255,0.1);
      color: #ffffff;
      border-left-color: #C8A8FF;
      backdrop-filter: blur(10px);
    }
    
    .sidebar-menu a.active {
      background: linear-gradient(45deg, #C8A8FF, #A78BFA);
      color: white;
      border-left-color: #E0C3FC;
      box-shadow: 0 4px 15px rgba(200, 168, 255, 0.4);
    }
    
    .sidebar-menu a i {
      margin-right: 12px;
      width: 20px;
      text-align: center;
    }
    
    .content {
      margin-left: 250px;
      padding: 0;
      background: linear-gradient(135deg, #F3E8FF 0%, #E9D5FF 50%, #DDD6FE 100%);
      min-height: 100vh;
    }
    
    .top-navbar {
      background: linear-gradient(45deg, #ffffff, #faf7ff);
      padding: 15px 30px;
      box-shadow: 0 2px 20px rgba(139, 93, 255, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      backdrop-filter: blur(10px);
    }
    
    .top-navbar h3 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
      text-shadow: 0 1px 2px rgba(107, 70, 193, 0.1);
    }
    
    .user-dropdown .dropdown-toggle {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 25px;
      padding: 8px 20px;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .user-dropdown .dropdown-toggle:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .main-content {
      padding: 30px;
    }
    
    .card-custom {
      background: linear-gradient(145deg, #ffffff, #fefcff);
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(139, 93, 255, 0.15);
      overflow: hidden;
      border: 1px solid rgba(200, 168, 255, 0.2);
      margin-bottom: 30px;
    }
    
    .card-header-custom {
      padding: 20px 25px;
      border-bottom: 1px solid rgba(200, 168, 255, 0.2);
      background: linear-gradient(45deg, #faf7ff, #f3e8ff);
    }
    
    .card-header-custom h5 {
      margin: 0;
      color: #6B46C1;
      font-weight: 600;
    }
    
    .card-body-custom {
      padding: 25px;
    }
    
    .form-control-custom {
      border: 1px solid rgba(139, 93, 255, 0.3);
      border-radius: 12px;
      padding: 12px 15px;
      transition: all 0.3s ease;
    }
    
    .form-control-custom:focus {
      border-color: #8B5DFF;
      box-shadow: 0 0 0 0.25rem rgba(139, 93, 255, 0.25);
    }
    
    .btn-primary-custom {
      background: linear-gradient(45deg, #8B5DFF, #7C4DFF);
      border: none;
      border-radius: 12px;
      padding: 12px 25px;
      color: white;
      font-weight: 600;
      box-shadow: 0 4px 15px rgba(139, 93, 255, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-primary-custom:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(139, 93, 255, 0.4);
    }
    
    .btn-secondary-custom {
      background: linear-gradient(45deg, #9ca3af, #6b7280);
      border: none;
      border-radius: 12px;
      padding: 12px 25px;
      color: white;
      font-weight: 600;
      box-shadow: 0 4px 15px rgba(156, 163, 175, 0.3);
      transition: all 0.3s ease;
    }
    
    .btn-secondary-custom:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(156, 163, 175, 0.4);
    }
    
    .img-preview {
      width: 120px;
      height: 120px;
      object-fit: cover;
      border-radius: 12px;
      border: 2px solid rgba(139, 93, 255, 0.2);
      box-shadow: 0 4px 10px rgba(139, 93, 255, 0.15);
    }
    
    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .content {
        margin-left: 0;
      }
      
      .main-content {
        padding: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div class="sidebar-header">
    <h4><i class="fas fa-archive"></i> ARSIP</h4>
    <div class="subtitle">Digital Archive System</div>
  </div>
  
  <div class="sidebar-menu">
    <a href="dashboard.php">
      <i class="fas fa-tachometer-alt"></i>
      Dashboard
    </a>
    <a href="data_kategori.php">
      <i class="fas fa-tags"></i>
      Data Kategori
    </a>
    <a href="data_petugas.php">
      <i class="fas fa-users-cog"></i>
      Data Petugas
    </a>
    <a href="data_user.php" class="active">
      <i class="fas fa-users"></i>
      Data User
    </a>
    <a href="data_arsip.php">
      <i class="fas fa-folder-open"></i>
      Data Arsip
    </a>
    <a href="riwayat_unduh.php">
      <i class="fas fa-download"></i>
      Riwayat Unduh
    </a>
    <a href="ganti_password.php">
      <i class="fas fa-key"></i>
      Ganti Password
    </a>
    <a href="logout.php">
      <i class="fas fa-sign-out-alt"></i>
      Logout
    </a>
  </div>
</div>

<!-- Content -->
<div class="content">
  <!-- Top Navbar -->
  <div class="top-navbar">
    <h3>Edit User - Sistem Informasi Arsip Digital</h3>
    <div class="user-dropdown dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-user-circle"></i>
        Administrator
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil Saya</a></li>
        <li><a class="dropdown-item" href="#"><i class="fas fa-key me-2"></i>Ganti Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#"><i class="fas fa-sign-out-alt me-2"></i>Log Out</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="card-custom">
      <div class="card-header-custom">
        <h5><i class="fas fa-edit me-2"></i>Edit User</h5>
      </div>
      <div class="card-body-custom">
        <form method="post" enctype="multipart/form-data">
          <div class="mb-4">
            <label class="form-label text-dark">Nama Lengkap</label>
            <input type="text" name="nama_user" class="form-control form-control-custom" value="<?= $data['nama_user']; ?>" required>
          </div>
          
          <div class="mb-4">
            <label class="form-label text-dark">Username</label>
            <input type="text" name="username" class="form-control form-control-custom" value="<?= $data['username']; ?>" required>
          </div>
          
          <div class="mb-4">
            <label class="form-label text-dark">Foto</label><br>
            <img src="../foto/<?= $data['foto']; ?>" class="img-preview mb-3" id="previewImage">
            <input type="file" name="foto" class="form-control form-control-custom" id="fotoInput" onchange="previewImage(event)">
          </div>
          
          <div class="d-flex gap-2">
            <button type="submit" name="update" class="btn btn-primary-custom">
              <i class="fas fa-save me-2"></i> Simpan Perubahan
            </button>
            <a href="data_user.php" class="btn btn-secondary-custom">
              <i class="fas fa-arrow-left me-2"></i> Kembali
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Function untuk preview gambar sebelum upload
  function previewImage(event) {
    const reader = new FileReader();
    reader.onload = function() {
      const output = document.getElementById('previewImage');
      output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  }

  // Add some interactive effects
  document.querySelectorAll('.form-control-custom').forEach(input => {
    input.addEventListener('focus', function() {
      this.style.transform = 'translateY(-2px)';
      this.style.boxShadow = '0 6px 20px rgba(139, 93, 255, 0.2)';
    });
    
    input.addEventListener('blur', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = 'none';
    });
  });
</script>
</body>
</html>