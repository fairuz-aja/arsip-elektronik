<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin | Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        --secondary-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        --accent-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        --success-gradient: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
        --danger-gradient: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
        --glass-bg: rgba(255, 255, 255, 0.15);
        --glass-border: rgba(255, 255, 255, 0.2);
        --text-primary: #ffffff;
        --text-secondary: rgba(255, 255, 255, 0.85);
        --text-dark: #2d3748;
        --shadow-light: 0 8px 32px rgba(31, 38, 135, 0.37);
        --shadow-heavy: 0 20px 60px rgba(0, 0, 0, 0.3);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        background: var(--primary-gradient);
        min-height: 100vh;
        position: relative;
        overflow-x: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Advanced animated background */
    .bg-animation {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
    }

    .floating-shapes {
        position: absolute;
        width: 100%;
        height: 100%;
    }

    .shape {
        position: absolute;
        background: linear-gradient(45deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
        border-radius: 50%;
        animation: float-around 25s infinite ease-in-out;
    }

    .shape:nth-child(1) {
        width: 120px;
        height: 120px;
        top: 10%;
        left: 15%;
        animation-delay: 0s;
        animation-duration: 30s;
    }

    .shape:nth-child(2) {
        width: 80px;
        height: 80px;
        top: 70%;
        right: 20%;
        animation-delay: 10s;
        animation-duration: 25s;
    }

    .shape:nth-child(3) {
        width: 100px;
        height: 100px;
        bottom: 20%;
        left: 70%;
        animation-delay: 15s;
        animation-duration: 35s;
    }

    @keyframes float-around {
        0%, 100% {
            transform: translateY(0px) translateX(0px) rotate(0deg);
        }
        25% {
            transform: translateY(-60px) translateX(40px) rotate(90deg);
        }
        50% {
            transform: translateY(-30px) translateX(-50px) rotate(180deg);
        }
        75% {
            transform: translateY(40px) translateX(30px) rotate(270deg);
        }
    }

    /* Particle system */
    .particles {
        position: absolute;
        width: 100%;
        height: 100%;
    }

    .particle {
        position: absolute;
        width: 4px;
        height: 4px;
        background: rgba(255, 255, 255, 0.6);
        border-radius: 50%;
        animation: particle-float 20s infinite linear;
    }

    .particle:nth-child(odd) {
        background: rgba(164, 176, 255, 0.8);
        animation-duration: 25s;
    }

    .particle:nth-child(even) {
        background: rgba(250, 112, 154, 0.6);
        animation-duration: 18s;
    }

    @keyframes particle-float {
        0% {
            transform: translateY(100vh) translateX(0px);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100px) translateX(150px);
            opacity: 0;
        }
    }

    /* Main login container */
    .login-container {
        position: relative;
        z-index: 10;
        width: 100%;
        max-width: 480px;
        padding: 20px;
        animation: slideInUp 1s cubic-bezier(0.4, 0, 0.2, 1);
    }

    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(50px) scale(0.9);
        }
        to {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    /* Header section */
    .login-header {
        text-align: center;
        margin-bottom: 40px;
        animation: fadeInDown 1s ease-out 0.3s both;
    }

    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .login-header .logo {
        width: 80px;
        height: 80px;
        margin: 0 auto 20px;
        background: var(--secondary-gradient);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        color: white;
        box-shadow: var(--shadow-light);
        animation: logo-pulse 3s ease-in-out infinite;
    }

    @keyframes logo-pulse {
        0%, 100% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(79, 172, 254, 0.4);
        }
        50% {
            transform: scale(1.05);
            box-shadow: 0 0 0 15px rgba(79, 172, 254, 0);
        }
    }

    .login-header h2 {
        font-size: 2rem;
        font-weight: 700;
        color: var(--text-primary);
        margin-bottom: 10px;
        background: linear-gradient(135deg, #ffffff 0%, #a4b0ff 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .login-header p {
        font-size: 1rem;
        color: var(--text-secondary);
        font-weight: 400;
    }

    /* Login box with advanced glassmorphism */
    .login-box {
        background: var(--glass-bg);
        backdrop-filter: blur(25px);
        border: 1px solid var(--glass-border);
        border-radius: 25px;
        padding: 40px;
        box-shadow: var(--shadow-heavy);
        position: relative;
        overflow: hidden;
        animation: glassAppear 1s ease-out 0.6s both;
    }

    @keyframes glassAppear {
        from {
            opacity: 0;
            transform: scale(0.9) rotateX(10deg);
        }
        to {
            opacity: 1;
            transform: scale(1) rotateX(0deg);
        }
    }

    .login-box::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
        animation: box-shine 3s infinite;
    }

    @keyframes box-shine {
        0% { left: -100%; }
        100% { left: 100%; }
    }

    .login-box h3 {
        text-align: center;
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 30px;
        position: relative;
    }

    .login-box h3::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 50%;
        transform: translateX(-50%);
        width: 50px;
        height: 3px;
        background: var(--secondary-gradient);
        border-radius: 2px;
    }

    /* Advanced form styling */
    .form-group {
        position: relative;
        margin-bottom: 25px;
        animation: slideInLeft 0.8s ease-out;
    }

    .form-group:nth-child(2) { animation-delay: 0.1s; }
    .form-group:nth-child(3) { animation-delay: 0.2s; }
    .form-group:nth-child(4) { animation-delay: 0.3s; }

    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-30px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    .form-group label {
        display: block;
        font-size: 0.9rem;
        font-weight: 500;
        color: var(--text-secondary);
        margin-bottom: 8px;
        transition: color 0.3s ease;
    }

    .input-wrapper {
        position: relative;
    }

    .input-wrapper i {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.6);
        font-size: 1.1rem;
        transition: all 0.3s ease;
    }

    .form-control {
        width: 100%;
        padding: 15px 15px 15px 50px;
        background: rgba(255, 255, 255, 0.1);
        border: 2px solid rgba(255, 255, 255, 0.2);
        border-radius: 15px;
        color: var(--text-primary);
        font-size: 1rem;
        font-weight: 400;
        backdrop-filter: blur(10px);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.5);
    }

    .form-control:focus {
        outline: none;
        border-color: rgba(79, 172, 254, 0.8);
        background: rgba(255, 255, 255, 0.15);
        box-shadow: 0 0 0 3px rgba(79, 172, 254, 0.2);
        transform: translateY(-2px);
    }

    .form-control:focus + .input-wrapper i,
    .form-group:hover .input-wrapper i {
        color: #4facfe;
        transform: translateY(-50%) scale(1.1);
    }

    .form-group:hover label {
        color: var(--text-primary);
    }

    /* Select dropdown styling */
    select.form-control {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23ffffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e");
        background-position: right 12px center;
        background-repeat: no-repeat;
        background-size: 16px;
        padding-right: 40px;
    }

    /* Advanced button styling */
    .btn-login {
        width: 100%;
        padding: 16px;
        background: var(--secondary-gradient);
        border: none;
        border-radius: 15px;
        color: white;
        font-size: 1.1rem;
        font-weight: 600;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        margin-top: 10px;
        box-shadow: 0 10px 25px rgba(79, 172, 254, 0.3);
        animation: slideInUp 0.8s ease-out 0.4s both;
    }

    .btn-login::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left 0.6s;
    }

    .btn-login::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, transparent 70%);
        transition: all 0.6s;
        transform: translate(-50%, -50%);
        border-radius: 50%;
    }

    .btn-login:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 15px 35px rgba(79, 172, 254, 0.4);
        background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%);
    }

    .btn-login:hover::before {
        left: 100%;
    }

    .btn-login:hover::after {
        width: 300px;
        height: 300px;
    }

    .btn-login:active {
        transform: translateY(-1px) scale(0.98);
    }

    /* Loading state */
    .btn-login.loading {
        pointer-events: none;
        opacity: 0.8;
    }

    .btn-login.loading::before {
        animation: loading-shine 1.5s infinite;
    }

    @keyframes loading-shine {
        0% { left: -100%; }
        100% { left: 100%; }
    }

    /* Back button */
    .back-btn {
        position: absolute;
        top: 30px;
        left: 30px;
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 20px;
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 25px;
        color: var(--text-primary);
        text-decoration: none;
        font-weight: 500;
        transition: all 0.3s ease;
        z-index: 20;
    }

    .back-btn:hover {
        background: rgba(255, 255, 255, 0.2);
        transform: translateX(-5px);
    }

    /* Responsive design */
    @media (max-width: 768px) {
        .login-container {
            max-width: 400px;
            padding: 15px;
        }

        .login-box {
            padding: 30px 25px;
            border-radius: 20px;
        }

        .login-header h2 {
            font-size: 1.7rem;
        }

        .back-btn {
            top: 20px;
            left: 20px;
            padding: 8px 15px;
        }
    }

    @media (max-width: 480px) {
        .login-container {
            max-width: 350px;
        }

        .login-box {
            padding: 25px 20px;
        }

        .login-header .logo {
            width: 60px;
            height: 60px;
            font-size: 1.5rem;
        }

        .login-header h2 {
            font-size: 1.5rem;
        }

        .form-control {
            padding: 12px 12px 12px 45px;
        }

        .btn-login {
            padding: 14px;
            font-size: 1rem;
        }
    }

    /* Focus indicators for accessibility */
    .form-control:focus,
    .btn-login:focus,
    .back-btn:focus {
        outline: 2px solid rgba(79, 172, 254, 0.5);
        outline-offset: 2px;
    }
</style>
<body>
    <!-- Advanced background animations -->
    <div class="bg-animation">
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>
        <div class="particles">
            <div class="particle" style="top: 20%; left: 15%; animation-delay: 0s;"></div>
            <div class="particle" style="top: 40%; left: 80%; animation-delay: 4s;"></div>
            <div class="particle" style="top: 70%; left: 25%; animation-delay: 8s;"></div>
            <div class="particle" style="top: 30%; left: 60%; animation-delay: 12s;"></div>
            <div class="particle" style="top: 80%; left: 70%; animation-delay: 16s;"></div>
            <div class="particle" style="top: 10%; left: 40%; animation-delay: 20s;"></div>
        </div>
    </div>

    <!-- Back button -->
    <a href="index.php" class="back-btn">
        <i class="fas fa-arrow-left"></i>
        Kembali
    </a>

    <div class="login-container">
        <!-- Header section -->
        <div class="login-header">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
            </div>
            <h2>Sistem Informasi<br>Arsip Digital</h2>
            <p>Silahkan login untuk mengakses panel administrasi</p>
        </div>

        <!-- Login form -->
        <div class="login-box">
            <h3>LOGIN ADMIN / PETUGAS</h3>
            <form action="proses/proses_login_admin.php" method="POST" id="loginForm">
                <div class="form-group">
                    <label for="username">Username</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" 
                               name="username" 
                               id="username"
                               class="form-control" 
                               placeholder="Masukkan username" 
                               required 
                               autocomplete="username">
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" 
                               name="password" 
                               id="password"
                               class="form-control" 
                               placeholder="Masukkan password" 
                               required 
                               autocomplete="current-password">
                    </div>
                </div>

                <div class="form-group">
                    <label for="hak_akses">Hak Akses</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user-cog"></i>
                        <select name="hak_akses" id="hak_akses" class="form-control" required>
                            <option value="">Pilih Hak Akses</option>
                            <option value="Admin">Admin</option>
                            <option value="Petugas">Petugas</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-login" id="loginBtn">
                    <i class="fas fa-sign-in-alt"></i>
                    Login Sekarang
                </button>
            </form>
        </div>
    </div>

    <script>
        // Enhanced form interactions
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('loginForm');
            const loginBtn = document.getElementById('loginBtn');
            const inputs = document.querySelectorAll('.form-control');

            // Add ripple effect to button
            loginBtn.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });

            // Enhanced input focus effects
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.parentElement.querySelector('label').style.transform = 'translateY(-5px)';
                });
                
                input.addEventListener('blur', function() {
                    if (!this.value) {
                        this.parentElement.parentElement.querySelector('label').style.transform = 'translateY(0)';
                    }
                });
            });

            // Form submission with loading state
            form.addEventListener('submit', function(e) {
                loginBtn.classList.add('loading');
                loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
            });
        });

        // Add CSS for ripple effect
        const style = document.createElement('style');
        style.textContent = `
            .ripple {
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                pointer-events: none;
                animation: ripple-animation 0.6s ease-out;
            }
            
            @keyframes ripple-animation {
                to {
                    transform: scale(2);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>