<?php
session_start();
include '../config/koneksi.php';

// Ambil data dari form
$username   = $_POST['username'] ?? '';
$password   = $_POST['password'] ?? '';
$hak_akses  = $_POST['hak_akses'] ?? '';

// Validasi form sederhana
if (empty($username) || empty($password) || empty($hak_akses)) {
    echo "<script>alert('Semua field harus diisi!');window.location='../login_admin.php';</script>";
    exit;
}

// Tentukan tabel sesuai hak akses
if ($hak_akses == 'Admin') {
    $table = 'tb_admin';
    $idKey = 'id_admin';
} elseif ($hak_akses == 'Petugas') {
    $table = 'petugas'; // pastikan tabelnya benar, sebelumnya kamu tulis 'petugas'
    $idKey = 'id_petugas';
} else {
    echo "<script>alert('Hak akses tidak valid!');window.location='../login_admin.php';</script>";
    exit;
}

// Ambil data user berdasarkan username
$query = mysqli_query($koneksi, "SELECT * FROM $table WHERE username='$username'");
$data  = mysqli_fetch_assoc($query);

if ($data) {
    // Verifikasi password (support hash & plain text untuk migrasi)
    if (password_verify($password, $data['password']) || $data['password'] === $password) {
        // Simpan session
        $_SESSION['username'] = $data['username'];
        $_SESSION['role']     = $hak_akses;
        $_SESSION['id_user']  = $data[$idKey]; // simpan id juga kalau perlu

        // Redirect sesuai role
        if ($hak_akses == 'Admin') {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../petugas/dashboard.php");
        }
        exit;
    } else {
        echo "<script>alert('Login gagal! Password salah.');window.location='../login_admin.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Login gagal! Username tidak ditemukan.');window.location='../login_admin.php';</script>";
    exit;
}
?>
