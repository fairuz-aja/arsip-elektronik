<?php
// edit_arsip.php
session_start();
include "../config/koneksi.php";

if(!isset($_SESSION['username'])){
    header("Location: ../login_admin.php");
    exit;
}

$id = $_GET['id'] ?? 0;
$query = mysqli_query($koneksi, "SELECT * FROM arsip WHERE id='$id'");
$data = mysqli_fetch_assoc($query);
$qkategori = mysqli_query($koneksi, "SELECT * FROM tb_kategori");
$qpetugas = mysqli_query($koneksi, "SELECT * FROM tb_petugas");

if(!$data){
    echo "Data tidak ditemukan.";
    exit;
}

// proses update
if(isset($_POST['update'])){
    $kode_arsip = $_POST['kode_arsip'];
    $nama_arsip = $_POST['nama_arsip'];
    $id_kategori = $_POST['id_kategori'];
    $id_petugas  = $_POST['id_petugas'];
    $keterangan = $_POST['keterangan'];

   $update = mysqli_query($koneksi, "UPDATE arsip SET 
    kode_arsip='$kode_arsip',
    nama_arsip='$nama_arsip',
    id_kategori='$id_kategori',
    id_petugas='$id_petugas',
    keterangan='$keterangan'
    WHERE id='$id'");

    if($update){
        header("Location: data_arsip.php?sukses=update");
        exit;
    } else {
        echo "Gagal update data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Arsip | Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #e0f2fe 0%, #b3e5fc 50%, #81d4fa 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #1976d2 0%, #1565c0 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(25, 118, 210, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #2196f3, #1976d2);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #64b5f6;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #64b5f6, #42a5f5);
            color: #0d47a1;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(100, 181, 246, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #e0f2fe 0%, #b3e5fc 50%, #81d4fa 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #1976d2, #1e88e5);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(25, 118, 210, 0.3);
            color: white;
        }
        
        .navbar-menu {
            display: flex;
            gap: 30px;
        }
        
        .navbar-menu a {
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .navbar-menu a:hover {
            color: #ffffff;
            text-shadow: 0 0 8px rgba(255,255,255,0.5);
        }
        
        .navbar-menu a.active {
            color: #ffffff;
            font-weight: 600;
        }
        
        .navbar-menu a.active::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 0;
            right: 0;
            height: 2px;
            background: #64b5f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: rgba(255,255,255,0.1);
            padding: 8px 15px;
            border-radius: 25px;
            backdrop-filter: blur(10px);
            cursor: pointer;
        }
        
        .user-info i {
            font-size: 1.2rem;
            margin-right: 8px;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            color: #1565c0;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .page-title {
            color: #0d47a1;
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 30px;
        }
        
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .card {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            transition: all 0.3s ease;
            border: 1px solid rgba(100, 181, 246, 0.2);
            position: relative;
            overflow: hidden;
        }
        
        .card:hover {
            box-shadow: 0 15px 40px rgba(25, 118, 210, 0.25);
            transform: translateY(-8px);
        }
        
        .card-icon {
            font-size: 24px;
            margin-bottom: 12px;
            width: 48px;
            height: 48px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .card.blue .card-icon {
            background: linear-gradient(135deg, #2196f3, #1976d2);
        }
        
        .card.indigo .card-icon {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
        }
        
        .card.cyan .card-icon {
            background: linear-gradient(135deg, #06b6d4, #0288d1);
        }
        
        .card h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 4px;
            color: #0d47a1;
        }
        
        .card p {
            font-size: 14px;
            color: #1565c0;
            margin: 0;
        }
        
        .welcome-section {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            padding: 24px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            margin-bottom: 24px;
            text-align: center;
            border: 1px solid rgba(100, 181, 246, 0.2);
        }
        
        .welcome-section h3 {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #0d47a1;
        }
        
        .welcome-section p {
            font-size: 14px;
            color: #1565c0;
            line-height: 1.6;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }
        
        .action-card {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(100, 181, 246, 0.2);
            cursor: pointer;
            text-decoration: none;
            color: inherit;
        }
        
        .action-card:hover {
            box-shadow: 0 15px 40px rgba(25, 118, 210, 0.25);
            transform: translateY(-8px);
            text-decoration: none;
            color: inherit;
        }
        
        .action-card i {
            font-size: 32px;
            margin-bottom: 12px;
            color: #1976d2;
        }
        
        .action-card h4 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #0d47a1;
        }
        
        .action-card p {
            font-size: 13px;
            color: #1565c0;
            margin: 0;
            line-height: 1.4;
        }
        
        /* Dropdown styles */
        .user-dropdown {
            position: relative;
        }
        
        .dropdown-menu {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(200, 200, 200, 0.2);
            min-width: 200px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow: hidden;
        }
        
        .dropdown-menu.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid rgba(200, 200, 200, 0.2);
            background: rgba(240, 240, 240, 0.5);
        }
        
        .dropdown-header h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #0d47a1;
        }
        
        .dropdown-header p {
            margin: 2px 0 0 0;
            font-size: 12px;
            color: #1565c0;
        }
        
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            text-decoration: none;
            color: #1565c0;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            background: none;
            width: 100%;
            cursor: pointer;
        }
        
        .dropdown-item:hover {
            background: rgba(200, 200, 200, 0.1);
            color: #0d47a1;
        }
        
        .dropdown-item i {
            font-size: 16px;
            width: 16px;
            text-align: center;
        }
        
        .dropdown-divider {
            height: 1px;
            background: rgba(200, 200, 200, 0.2);
            margin: 4px 0;
        }
        
        /* Form specific styles */
        .form-card {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            border: 1px solid rgba(100, 181, 246, 0.2);
            margin-bottom: 30px;
        }
        
        .form-card-header {
            padding-bottom: 20px;
            margin-bottom: 25px;
            border-bottom: 1px solid rgba(100, 181, 246, 0.2);
        }
        
        .form-card-header h4 {
            color: #0d47a1;
            font-weight: 600;
            margin: 0;
        }
        
        .form-card-header p {
            color: #1565c0;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .form-label {
            color: #0d47a1;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border: 1px solid rgba(100, 181, 246, 0.3);
            border-radius: 12px;
            padding: 12px 15px;
            transition: all 0.3s ease;
            background: white;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #1976d2;
            box-shadow: 0 0 0 0.25rem rgba(25, 118, 210, 0.25);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 25px;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }
        
        .btn-warning {
            background: linear-gradient(45deg, #2196f3, #1976d2);
            color: white;
        }
        
        .btn-warning:hover {
            background: linear-gradient(45deg, #1976d2, #1565c0);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(25, 118, 210, 0.3);
            color: white;
        }
        
        .btn-secondary {
            background: linear-gradient(45deg, #9ca3af, #6b7280);
            color: white;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(45deg, #6b7280, #4b5563);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(107, 114, 128, 0.3);
            color: white;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .cards {
                grid-template-columns: 1fr;
            }
            
            .quick-actions {
                grid-template-columns: 1fr;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .navbar-menu {
                display: none;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php" class="active">
            <i class="fas fa-folder-open"></i>
            Data Arsip
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="navbar-menu">
            <a href="dashboard.php">Home</a>
            <a href="data_arsip.php" class="active">Semua Arsip</a>
            <a href="#">Kategori</a>
        </div>
        
        <div class="user-info" onclick="toggleDropdown()">
            <i class="fas fa-user-circle"></i>
            <?php echo $_SESSION['username']; ?> [User]
            <div class="dropdown-menu" id="userDropdown">
                <div class="dropdown-header">
                    <h6><?php echo $_SESSION['username']; ?></h6>
                    <p>User</p>
                </div>
                <a href="profil_saya.php" class="dropdown-item">
                    <i class="fas fa-user"></i>
                    Profil Saya
                </a>
                <a href="ganti_password.php" class="dropdown-item">
                    <i class="fas fa-key"></i>
                    Ganti Password
                </a>
                <div class="dropdown-divider"></div>
                <a href="../logout.php" class="dropdown-item" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fas fa-sign-out-alt"></i>
                    Log Out
                </a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Data Arsip</span>
            <i class="fas fa-chevron-right"></i>
            <span>Edit Arsip</span>
        </div>
        
        <!-- Page Title -->
        <h1 class="page-title">Edit Arsip</h1>
        
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h3>Perbarui Informasi Arsip Digital</h3>
            <p>Edit informasi arsip digital dengan mengisi form di bawah ini.</p>
        </div>

        <!-- Form Card -->
        <div class="form-card">
            <div class="form-card-header">
                <h4><i class="fas fa-edit me-2"></i>Form Edit Arsip</h4>
                <p>Perbarui informasi arsip digital pada form di bawah ini</p>
            </div>
            
            <form method="POST">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Kode Arsip</label>
                            <input type="text" name="kode_arsip" value="<?= $data['kode_arsip'] ?>" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Nama Arsip</label>
                            <input type="text" name="nama_arsip" value="<?= $data['nama_arsip'] ?>" class="form-control" required>
                        </div>
                    </div>
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select name="id_kategori" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php 
                                // Reset pointer untuk query kategori
                                mysqli_data_seek($qkategori, 0);
                                while($k = mysqli_fetch_assoc($qkategori)) { 
                                ?>
                                    <option value="<?= $k['id_kategori']; ?>" 
                                        <?= ($data['id_kategori'] == $k['id_kategori']) ? 'selected' : ''; ?>>
                                        <?= $k['nama_kategori']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Petugas</label>
                            <select name="id_petugas" class="form-select" required>
                                <option value="">-- Pilih Petugas --</option>
                                <?php 
                                // Reset pointer untuk query petugas
                                mysqli_data_seek($qpetugas, 0);
                                while($p = mysqli_fetch_assoc($qpetugas)) { 
                                ?>
                                    <option value="<?= $p['id_petugas']; ?>" 
                                        <?= ($data['id_petugas'] == $p['id_petugas']) ? 'selected' : ''; ?>>
                                        <?= $p['nama']; ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="4"><?= $data['keterangan'] ?></textarea>
                </div>
                
                <div class="d-flex gap-2">
                    <button type="submit" name="update" class="btn btn-warning">
                        <i class="fas fa-save me-2"></i>Update Arsip
                    </button>
                    <a href="data_arsip.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Add some interactive effects
document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-12px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0) scale(1)';
    });
});

// Dropdown functionality
function toggleDropdown() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('show');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const userInfo = document.querySelector('.user-info');
    const dropdown = document.getElementById('userDropdown');
    
    if (!userInfo.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});

// Close dropdown with ESC key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const dropdown = document.getElementById('userDropdown');
        dropdown.classList.remove('show');
    }
});

// Form input effects
document.querySelectorAll('.form-control, .form-select').forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });
});
</script>
</body>
</html>