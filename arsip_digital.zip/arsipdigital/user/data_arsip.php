<?php
// data_arsip.php

session_start();
include "../config/koneksi.php"; // koneksi ke database

// cek login
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

// ambil data arsip dari database
$query = "SELECT * FROM arsip ORDER BY waktu_upload DESC";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Arsip | Sistem Informasi Arsip Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
</head>
<style>
:root {
    --primary: #2563eb;
    --primary-dark: #1d4ed8;
    --primary-light: #dbeafe;
    --primary-gradient: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
    --primary-gradient-light: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
    --secondary: #4f46e5;
    --accent: #6366f1;
    --success: #10b981;
    --info: #06b6d4;
    --warning: #f59e0b;
    --danger: #ef4444;
    --dark: #1e293b;
    --light-blue: #e0f2fe;
    --light-blue-2: #bae6fd;
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
    --gray-900: #0f172a;
    --white: #ffffff;
    --shadow-sm: 0 1px 3px rgba(37, 99, 235, 0.12);
    --shadow: 0 4px 6px rgba(37, 99, 235, 0.15);
    --shadow-md: 0 5px 15px rgba(37, 99, 235, 0.2);
    --shadow-lg: 0 10px 25px rgba(37, 99, 235, 0.25);
    --border-radius: 12px;
    --border-radius-lg: 16px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    color: var(--gray-800);
    line-height: 1.6;
    font-size: 15px;
    min-height: 100vh;
}

.container {
    display: flex;
    min-height: 100vh;
}

/* Sidebar Styles */
.sidebar {
    width: 280px;
    background: var(--primary-gradient);
    box-shadow: var(--shadow-md);
    transition: var(--transition);
    z-index: 100;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.sidebar-header {
    padding: 24px;
    text-align: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header .logo {
    font-weight: 700;
    font-size: 24px;
    color: var(--white);
    letter-spacing: 0.5px;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.sidebar-nav {
    padding: 24px 16px;
    flex-grow: 1;
}

.sidebar-nav ul {
    list-style: none;
}

.sidebar-nav ul li {
    margin-bottom: 8px;
}

.sidebar-nav ul li a {
    display: flex;
    align-items: center;
    padding: 14px 16px;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.9);
    font-weight: 500;
    border-radius: var(--border-radius);
    transition: var(--transition);
}

.sidebar-nav ul li a:hover,
.sidebar-nav ul li a.active {
    background: rgba(255, 255, 255, 0.15);
    color: var(--white);
    backdrop-filter: blur(10px);
}

.sidebar-nav ul li a i {
    margin-right: 12px;
    font-size: 18px;
    width: 24px;
    text-align: center;
}

.sidebar-footer {
    padding: 16px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    text-align: center;
    color: rgba(255, 255, 255, 0.7);
    font-size: 13px;
}

/* Main Content Styles */
.main-content {
    flex-grow: 1;
    padding: 30px;
    overflow-y: auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--white);
    padding: 20px 28px;
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow);
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}

.header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
    background: var(--primary-gradient);
}

.header h1 {
    color: var(--primary-dark);
    font-weight: 700;
    font-size: 28px;
    letter-spacing: -0.5px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 16px;
}

.welcome-text {
    color: var(--gray-600);
    font-size: 15px;
    font-weight: 500;
}

.welcome-text .username {
    color: var(--primary);
    font-weight: 600;
}

.user-dropdown {
    position: relative;
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    padding: 10px 16px;
    border-radius: var(--border-radius);
    transition: var(--transition);
    background: var(--light-blue);
    border: 1px solid var(--primary-light);
}

.user-dropdown:hover {
    background: var(--primary-light);
    box-shadow: var(--shadow-sm);
}

.profile-img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--primary-gradient);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    font-weight: 700;
    color: var(--white);
    box-shadow: var(--shadow-sm);
}

.user-details {
    display: flex;
    flex-direction: column;
}

.user-details span:first-child {
    font-weight: 600;
    color: var(--gray-800);
    font-size: 14px;
}

.user-details span:last-child {
    font-size: 12px;
    color: var(--gray-500);
}

.dropdown-arrow {
    font-size: 12px;
    color: var(--primary);
    transition: var(--transition);
}

.user-dropdown.active .dropdown-arrow {
    transform: rotate(180deg);
}

.dropdown-menu {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    background: var(--white);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-lg);
    border: 1px solid var(--primary-light);
    min-width: 220px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: var(--transition);
    z-index: 1000;
    overflow: hidden;
}

.dropdown-menu.show {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.dropdown-header {
    padding: 16px;
    border-bottom: 1px solid var(--gray-100);
    background: var(--light-blue);
}

.dropdown-header h6 {
    margin: 0;
    font-size: 15px;
    font-weight: 700;
    color: var(--primary-dark);
}

.dropdown-header p {
    margin: 4px 0 0 0;
    font-size: 12px;
    color: var(--primary);
}

.dropdown-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    text-decoration: none;
    color: var(--gray-700);
    font-size: 14px;
    font-weight: 500;
    transition: var(--transition);
    border: none;
    background: none;
    width: 100%;
    cursor: pointer;
}

.dropdown-item:hover {
    background: var(--light-blue);
    color: var(--primary);
    padding-left: 20px;
}

.dropdown-item i {
    font-size: 16px;
    width: 16px;
    text-align: center;
    color: var(--primary);
}

.dropdown-divider {
    height: 1px;
    background: var(--gray-200);
    margin: 4px 0;
}

/* Breadcrumb */
.breadcrumb {
    margin: 0 0 28px;
    font-size: 14px;
    color: var(--gray-500);
    display: flex;
    align-items: center;
    gap: 8px;
}

.breadcrumb a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 500;
    transition: var(--transition);
}

.breadcrumb a:hover {
    color: var(--primary-dark);
    text-decoration: underline;
}

.breadcrumb i {
    font-size: 12px;
    color: var(--gray-400);
}

/* Welcome Section */
.welcome-section {
    background: var(--white);
    padding: 28px;
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow);
    margin-bottom: 30px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.welcome-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--primary-gradient);
}

.welcome-section h2 {
    font-size: 26px;
    font-weight: 700;
    margin-bottom: 12px;
    color: var(--primary-dark);
}

.welcome-section p {
    font-size: 16px;
    color: var(--gray-600);
    line-height: 1.6;
    max-width: 700px;
    margin: 0 auto;
}

/* Card Styles */
.card {
    background: var(--white);
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow);
    margin-bottom: 30px;
    overflow: hidden;
}

.card-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--gray-200);
    background: var(--gray-50);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-header h5 {
    margin: 0;
    color: var(--primary-dark);
    font-weight: 600;
    display: flex;
    align-items: center;
}

.card-header h5 i {
    margin-right: 10px;
    font-size: 1.2rem;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    font-size: 0.9rem;
    cursor: pointer;
}

.btn i {
    margin-right: 8px;
}

.btn-primary {
    background: var(--primary-gradient);
    color: white;
    box-shadow: var(--shadow);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.btn-sm {
    padding: 6px 12px;
    font-size: 0.8rem;
    margin: 2px;
}

.btn-dark {
    background: linear-gradient(45deg, #374151, #1f2937);
    color: white;
    box-shadow: var(--shadow);
}

.btn-warning {
    background: linear-gradient(45deg, #f59e0b, #d97706);
    color: white;
    box-shadow: var(--shadow);
}

.btn-danger {
    background: linear-gradient(45deg, #ef4444, #dc2626);
    color: white;
    box-shadow: var(--shadow);
}

.btn-dark:hover, .btn-warning:hover, .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.card-body {
    padding: 25px;
}

/* Alert Styles */
.alert {
    background: linear-gradient(45deg, #dcfce7, #bbf7d0);
    color: #166534;
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    border: 1px solid #86efac;
    box-shadow: var(--shadow-sm);
    display: flex;
    align-items: center;
}

.alert i {
    margin-right: 10px;
    font-size: 1.2rem;
}

/* DataTable Styling */
.dataTables_wrapper {
    margin-top: 20px;
}

.dataTables_length select,
.dataTables_filter input {
    padding: 8px 12px;
    border: 2px solid var(--gray-300);
    border-radius: 25px;
    background: white;
    color: var(--primary);
    font-size: 0.9rem;
}

.dataTables_length select:focus,
.dataTables_filter input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-light);
}

.dataTables_length label,
.dataTables_filter label {
    color: var(--primary);
    font-weight: 600;
}

table.dataTable {
    border-collapse: separate;
    border-spacing: 0;
    width: 100% !important;
}

table.dataTable thead th {
    background: var(--primary-light);
    color: var(--primary-dark);
    font-weight: 600;
    padding: 15px 10px;
    border: none;
    text-align: center;
    font-size: 0.9rem;
}

table.dataTable thead th:first-child {
    border-radius: 12px 0 0 0;
}

table.dataTable thead th:last-child {
    border-radius: 0 12px 0 0;
}

table.dataTable tbody td {
    padding: 12px 10px;
    border-bottom: 1px solid var(--gray-200);
    color: var(--gray-700);
    font-size: 0.85rem;
    vertical-align: middle;
}

table.dataTable tbody tr:hover {
    background: var(--gray-50);
}

table.dataTable tbody tr:nth-child(even) {
    background: var(--gray-50);
}

.dataTables_info,
.dataTables_paginate {
    color: var(--primary) !important;
    font-weight: 600;
}

.dataTables_paginate .paginate_button {
    padding: 8px 12px !important;
    margin: 0 2px !important;
    border-radius: 8px !important;
    border: 1px solid var(--gray-300) !important;
    background: white !important;
    color: var(--primary) !important;
}

.dataTables_paginate .paginate_button:hover {
    background: var(--primary-light) !important;
    color: var(--primary-dark) !important;
}

.dataTables_paginate .paginate_button.current {
    background: var(--primary-gradient) !important;
    color: white !important;
}

.archive-info {
    line-height: 1.4;
}

.archive-info strong {
    color: var(--primary);
    font-weight: 600;
}

.archive-info br {
    margin-bottom: 5px;
}

/* Mobile Responsive */
@media (max-width: 992px) {
    .container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
    }
    
    .sidebar-nav {
        padding: 16px;
    }
    
    .sidebar-nav ul {
        display: flex;
        overflow-x: auto;
        padding-bottom: 8px;
    }
    
    .sidebar-nav ul li {
        margin-bottom: 0;
        margin-right: 8px;
    }
    
    .main-content {
        padding: 20px;
    }

    .header {
        flex-direction: column;
        gap: 16px;
        text-align: center;
        padding: 20px;
    }

    .header h1 {
        font-size: 24px;
    }

    .btn-sm {
        padding: 4px 8px;
        font-size: 0.75rem;
    }
    
    table.dataTable {
        font-size: 0.8rem;
    }
}

@media (max-width: 576px) {
    .main-content {
        padding: 16px;
    }
    
    .user-info {
        flex-direction: column;
        gap: 12px;
    }
    
    .user-dropdown {
        width: 100%;
        justify-content: center;
    }
    
    .welcome-section h2 {
        font-size: 22px;
    }
    
    .welcome-section p {
        font-size: 14px;
    }
    
    .card-header {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start;
    }
}

/* Smooth animations */
.stat-card, .action-card {
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInUp 0.5s ease forwards;
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }

.action-card:nth-child(1) { animation-delay: 0.4s; }
.action-card:nth-child(2) { animation-delay: 0.5s; }
.action-card:nth-child(3) { animation-delay: 0.6s; }

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Scrollbar styling */
.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.5);
}
</style>

<body>
    <div class="container">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="logo">SISTEM ARSIP DIGITAL</div>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="dashboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="data_arsip.php" class="active">
                            <i class="fas fa-archive"></i>
                            <span>Data Arsip</span>
                        </a>
                    </li>
                    <li>
                        <a href="ganti_password.php">
                            <i class="fas fa-key"></i>
                            <span>Ganti Password</span>
                        </a>
                    </li>
                    <li>
                        <a href="logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                &copy; 2025 Sistem Informasi Arsip Digital
            </div>
        </div>

        <div class="main-content">
            <div class="header">
                <h1>Data Arsip</h1>
                <div class="user-info">
                    <div class="welcome-text">
                        Selamat datang, <span class="username">Admin</span>
                    </div>
                    
                    <div class="user-dropdown" onclick="toggleDropdown()">
                        <div class="profile-img">A</div>
                        <div class="user-details">
                            <span>Administrator</span>
                            <span>Admin</span>
                        </div>
                        <i class="fas fa-chevron-down dropdown-arrow"></i>
                        
                        <div class="dropdown-menu" id="userDropdown">
                            <div class="dropdown-header">
                                <h6>Administrator</h6>
                                <p>admin@example.com</p>
                            </div>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-user"></i>
                                Profil Saya
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-key"></i>
                                Ganti Password
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="#" class="dropdown-item">
                                <i class="fas fa-sign-out-alt"></i>
                                Log Out
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="breadcrumb">
                <a href="#"><i class="fas fa-home"></i> Home</a> / Data Arsip
            </div>

            <div class="welcome-section">
                <h2>Kelola Data Arsip Digital</h2>
                <p>Lihat, edit, dan kelola semua arsip digital yang tersimpan dalam sistem. Anda dapat mengunggah, melihat pratinjau, mengedit, atau menghapus arsip.</p>
            </div>

            <?php if (isset($_GET['sukses'])) { ?>
                <div class="alert">
                    <i class="fas fa-check-circle"></i>
                    Arsip berhasil tersimpan.
                </div>
            <?php } ?>

            <div class="card">
                <div class="card-header">
                    <h5>
                        <i class="fas fa-folder-open"></i>
                        Daftar Arsip
                    </h5>
                </div>
                <div class="card-body">
                    <table id="tabelArsip" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Waktu Upload</th>
                                <th>Arsip</th>
                                <th>Kategori</th>
                                <th>Petugas</th>
                                <th>Keterangan</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            if(mysqli_num_rows($result) > 0){
                                while($row = mysqli_fetch_assoc($result)){ ?>
                                    <tr>
                                        <td style="text-align: center; font-weight: 600;"><?= $no++ ?></td>
                                        <td style="text-align: center; font-weight: 500;">
                                            <?= date('H:i:s d-m-Y', strtotime($row['waktu_upload'])) ?>
                                        </td>
                                        <td class="archive-info">
                                            <strong>KODE:</strong> <?= htmlspecialchars($row['kode_arsip']) ?><br>
                                            <strong>Nama:</strong> <?= htmlspecialchars($row['nama_arsip']) ?><br>
                                            <strong>Jenis:</strong> <?= strtoupper(pathinfo($row['file_path'], PATHINFO_EXTENSION)) ?>
                                        </td>
                                        <td style="text-align: center; font-weight: 500;">
                                            <?= htmlspecialchars($row['kategori']) ?>
                                        </td>
                                        <td style="text-align: center; font-weight: 500;">
                                            <?= htmlspecialchars($row['petugas']) ?>
                                        </td>
                                        <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                        <td style="text-align: center;">
                                            <a href="preview_arsip.php?id=<?= $row['id'] ?>" class="btn btn-dark btn-sm">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit_arsip.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="hapus_arsip.php?id=<?= $row['id'] ?>" 
                                               onclick="return confirm('Yakin ingin hapus arsip ini?')" 
                                               class="btn btn-danger btn-sm">
                                               <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                            <?php }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            const userDropdown = document.querySelector('.user-dropdown');
            
            dropdown.classList.toggle('show');
            userDropdown.classList.toggle('active');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userDropdown = document.querySelector('.user-dropdown');
            const dropdown = document.getElementById('userDropdown');
            
            if (!userDropdown.contains(event.target)) {
                dropdown.classList.remove('show');
                userDropdown.classList.remove('active');
            }
        });

        // Close dropdown with ESC key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const dropdown = document.getElementById('userDropdown');
                const userDropdown = document.querySelector('.user-dropdown');
                
                dropdown.classList.remove('show');
                userDropdown.classList.remove('active');
            }
        });

        $(document).ready(function() {
            $('#tabelArsip').DataTable({
                "language": {
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
                    "infoEmpty": "Tidak ada data yang tersedia",
                    "infoFiltered": "(difilter dari _MAX_ total data)",
                    "search": "Cari:",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelumnya"
                    }
                },
                "pageLength": 10,
                "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "Semua"]],
                "responsive": true,
                "order": [[ 1, "desc" ]]
            });

            // Add hover effects to buttons
            document.querySelectorAll('.btn').forEach(btn => {
                btn.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px) scale(1.05)';
                });
                
                btn.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
        });
    </script>
</body>
</html>