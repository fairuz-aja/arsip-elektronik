<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Unduh | Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #e0f2fe 0%, #b3e5fc 50%, #81d4fa 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #1976d2 0%, #1565c0 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(25, 118, 210, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #2196f3, #1976d2);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #64b5f6;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #64b5f6, #42a5f5);
            color: #0d47a1;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(100, 181, 246, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #e0f2fe 0%, #b3e5fc 50%, #81d4fa 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #1976d2, #1e88e5);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(25, 118, 210, 0.3);
            color: white;
        }
        
        .navbar-menu {
            display: flex;
            gap: 30px;
        }
        
        .navbar-menu a {
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .navbar-menu a:hover {
            color: #ffffff;
            text-shadow: 0 0 8px rgba(255,255,255,0.5);
        }
        
        .navbar-menu a.active {
            color: #ffffff;
            font-weight: 600;
        }
        
        .navbar-menu a.active::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 0;
            right: 0;
            height: 2px;
            background: #64b5f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: rgba(255,255,255,0.1);
            padding: 8px 15px;
            border-radius: 25px;
            backdrop-filter: blur(10px);
            cursor: pointer;
        }
        
        .user-info i {
            font-size: 1.2rem;
            margin-right: 8px;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            color: #1565c0;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .page-title {
            color: #0d47a1;
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 30px;
        }
        
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            transition: all 0.3s ease;
            border: 1px solid rgba(100, 181, 246, 0.2);
            text-align: center;
        }
        
        .stat-card:hover {
            box-shadow: 0 15px 40px rgba(25, 118, 210, 0.25);
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 32px;
            margin-bottom: 12px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
        }
        
        .stat-card.blue .stat-icon {
            background: linear-gradient(135deg, #2196f3, #1976d2);
        }
        
        .stat-card.green .stat-icon {
            background: linear-gradient(135deg, #4caf50, #2e7d32);
        }
        
        .stat-card.orange .stat-icon {
            background: linear-gradient(135deg, #ff9800, #f57c00);
        }
        
        .stat-card h3 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 4px;
            color: #0d47a1;
        }
        
        .stat-card p {
            font-size: 14px;
            color: #1565c0;
            margin: 0;
        }
        
        .filter-container {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            margin-bottom: 24px;
            border: 1px solid rgba(100, 181, 246, 0.2);
        }
        
        .filter-options {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-label {
            font-weight: 600;
            margin-bottom: 5px;
            color: #1565c0;
            font-size: 14px;
        }
        
        .filter-select {
            padding: 8px 12px;
            border: 1px solid rgba(100, 181, 246, 0.5);
            border-radius: 6px;
            font-size: 14px;
            background: white;
            min-width: 150px;
        }
        
        .date-range {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .date-input {
            padding: 8px 12px;
            border: 1px solid rgba(100, 181, 246, 0.5);
            border-radius: 6px;
            font-size: 14px;
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            margin-left: auto;
        }
        
        .filter-btn {
            background: linear-gradient(135deg, #2196f3, #1976d2);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .filter-btn:hover {
            background: linear-gradient(135deg, #1976d2, #1565c0);
        }
        
        .reset-btn {
            background: rgba(100, 181, 246, 0.2);
            color: #1976d2;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .reset-btn:hover {
            background: rgba(100, 181, 246, 0.3);
        }
        
        .history-table {
            background: linear-gradient(145deg, #ffffff, #f8fcff);
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(25, 118, 210, 0.15);
            overflow: hidden;
            border: 1px solid rgba(100, 181, 246, 0.2);
        }
        
        .table-header {
            background: linear-gradient(45deg, #2196f3, #1976d2);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        .table-actions {
            display: flex;
            gap: 10px;
        }
        
        .table-action-btn {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s ease;
        }
        
        .table-action-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            background: rgba(100, 181, 246, 0.1);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #0d47a1;
            border-bottom: 1px solid rgba(100, 181, 246, 0.3);
        }
        
        td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(100, 181, 246, 0.1);
            color: #1565c0;
        }
        
        tr:hover {
            background: rgba(100, 181, 246, 0.05);
        }
        
        .file-icon {
            font-size: 20px;
            margin-right: 8px;
            color: #1976d2;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-completed {
            background: rgba(76, 175, 80, 0.2);
            color: #2e7d32;
        }
        
        .status-failed {
            background: rgba(244, 67, 54, 0.2);
            color: #c62828;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .btn {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
        }
        
        .btn-download {
            background: rgba(76, 175, 80, 0.2);
            color: #2e7d32;
        }
        
        .btn-download:hover {
            background: rgba(76, 175, 80, 0.3);
        }
        
        .btn-view {
            background: rgba(100, 181, 246, 0.2);
            color: #1976d2;
        }
        
        .btn-view:hover {
            background: rgba(100, 181, 246, 0.3);
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            padding: 20px;
            gap: 8px;
        }
        
        .page-btn {
            padding: 8px 12px;
            border: 1px solid rgba(100, 181, 246, 0.3);
            background: white;
            color: #1976d2;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .page-btn.active {
            background: #1976d2;
            color: white;
        }
        
        .page-btn:hover:not(.active) {
            background: rgba(100, 181, 246, 0.1);
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #1565c0;
        }
        
        .no-data i {
            font-size: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        .dropdown-menu {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(200, 200, 200, 0.2);
            min-width: 200px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 1000;
            overflow: hidden;
        }
        
        .dropdown-menu.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .dropdown-header {
            padding: 12px 16px;
            border-bottom: 1px solid rgba(200, 200, 200, 0.2);
            background: rgba(240, 240, 240, 0.5);
        }
        
        .dropdown-header h6 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #0d47a1;
        }
        
        .dropdown-header p {
            margin: 2px 0 0 0;
            font-size: 12px;
            color: #1565c0;
        }
        
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            text-decoration: none;
            color: #1565c0;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            background: none;
            width: 100%;
            cursor: pointer;
        }
        
        .dropdown-item:hover {
            background: rgba(200, 200, 200, 0.1);
            color: #0d47a1;
        }
        
        .dropdown-item i {
            font-size: 16px;
            width: 16px;
            text-align: center;
        }
        
        .dropdown-divider {
            height: 1px;
            background: rgba(200, 200, 200, 0.2);
            margin: 4px 0;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .navbar-menu {
                display: none;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .filter-options {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .filter-actions {
                margin-left: 0;
                width: 100%;
                justify-content: flex-end;
            }
            
            .date-range {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .table-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="lihat_arsip.php">
            <i class="fas fa-folder-open"></i>
            Lihat Arsip
        </a>
        <a href="cari_arsip.php">
            <i class="fas fa-search"></i>
            Cari Arsip
        </a>
        <a href="riwayat_unduh.php" class="active">
            <i class="fas fa-history"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="navbar-menu">
            <a href="dashboard.php">Home</a>
            <a href="lihat_arsip.php">Lihat Arsip</a>
            <a href="cari_arsip.php">Cari Arsip</a>
            <a href="riwayat_unduh.php" class="active">Riwayat Unduh</a>
        </div>
        
        <div class="user-info" onclick="toggleDropdown()">
            <i class="fas fa-user-circle"></i>
            Ifatul Inayah [User]
            <div class="dropdown-menu" id="userDropdown">
                <div class="dropdown-header">
                    <h6>Ifatul Inayah</h6>
                    <p>User</p>
                </div>
                <a href="profil_saya.php" class="dropdown-item">
                    <i class="fas fa-user"></i>
                    Profil Saya
                </a>
                <a href="ganti_password.php" class="dropdown-item">
                    <i class="fas fa-key"></i>
                    Ganti Password
                </a>
                <div class="dropdown-divider"></div>
                <a href="../logout.php" class="dropdown-item" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                    <i class="fas fa-sign-out-alt"></i>
                    Log Out
                </a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Riwayat Unduh</span>
        </div>
        
        <!-- Page Title -->
        <h1 class="page-title">Riwayat Unduh</h1>
        
        <!-- Statistics Cards -->
        <div class="stats-cards">
            <div class="stat-card blue">
                <div class="stat-icon">
                    <i class="fas fa-download"></i>
                </div>
                <h3>25</h3>
                <p>Total Unduhan</p>
            </div>
            <div class="stat-card green">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>23</h3>
                <p>Unduhan Berhasil</p>
            </div>
            <div class="stat-card orange">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>2.5 GB</h3>
                <p>Total Ukuran</p>
            </div>
        </div>
        
        <!-- Filter Section -->
        <div class="filter-container">
            <div class="filter-options">
                <div class="filter-group">
                    <label class="filter-label">Periode Waktu</label>
                    <select class="filter-select" id="timePeriod">
                        <option value="7days">7 Hari Terakhir</option>
                        <option value="30days">30 Hari Terakhir</option>
                        <option value="90days">90 Hari Terakhir</option>
                        <option value="custom">Kustom</option>
                    </select>
                </div>
                
                <div class="filter-group" id="customDateRange" style="display: none;">
                    <label class="filter-label">Rentang Tanggal</label>
                    <div class="date-range">
                        <input type="date" class="date-input" id="startDate">
                        <span>s/d</span>
                        <input type="date" class="date-input" id="endDate">
                    </div>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Status</label>
                    <select class="filter-select">
                        <option value="">Semua Status</option>
                        <option value="completed">Berhasil</option>
                        <option value="failed">Gagal</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Jenis File</label>
                    <select class="filter-select">
                        <option value="">Semua Jenis</option>
                        <option value="pdf">PDF</option>
                        <option value="doc">Dokumen Word</option>
                        <option value="xls">Spreadsheet</option>
                        <option value="img">Gambar</option>
                    </select>
                </div>
                
                <div class="filter-actions">
                    <button class="filter-btn"><i class="fas fa-filter"></i> Terapkan Filter</button>
                    <button class="reset-btn"><i class="fas fa-redo"></i> Reset</button>
                </div>
            </div>
        </div>
        
        <!-- History Table -->
        <div class="history-table">
            <div class="table-header">
                <div class="table-title">Riwayat Unduhan Anda</div>
                <div class="table-actions">
                    <button class="table-action-btn"><i class="fas fa-sync-alt"></i> Refresh</button>
                    <button class="table-action-btn"><i class="fas fa-file-export"></i> Ekspor</button>
                </div>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Nama File</th>
                            <th>Kategori</th>
                            <th>Tanggal Unduh</th>
                            <th>Ukuran</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><i class="fas fa-file-pdf file-icon"></i> Laporan Keuangan 2023.pdf</td>
                            <td>Keuangan</td>
                            <td>15 Jan 2023, 14:30</td>
                            <td>2.5 MB</td>
                            <td><span class="status-badge status-completed">Berhasil</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-view"><i class="fas fa-eye"></i> Lihat</button>
                                    <button class="btn btn-download"><i class="fas fa-download"></i> Unduh Ulang</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-file-word file-icon"></i> SOP Administrasi.docx</td>
                            <td>Administrasi</td>
                            <td>12 Jan 2023, 09:15</td>
                            <td>1.8 MB</td>
                            <td><span class="status-badge status-completed">Berhasil</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-view"><i class="fas fa-eye"></i> Lihat</button>
                                    <button class="btn btn-download"><i class="fas fa-download"></i> Unduh Ulang</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-file-excel file-icon"></i> Data Karyawan.xlsx</td>
                            <td>SDM</td>
                            <td>10 Jan 2023, 16:45</td>
                            <td>3.2 MB</td>
                            <td><span class="status-badge status-completed">Berhasil</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-view"><i class="fas fa-eye"></i> Lihat</button>
                                    <button class="btn btn-download"><i class="fas fa-download"></i> Unduh Ulang</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-file-pdf file-icon"></i> Laporan Proyek A.pdf</td>
                            <td>Proyek</td>
                            <td>05 Jan 2023, 11:20</td>
                            <td>4.7 MB</td>
                            <td><span class="status-badge status-failed">Gagal</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-view"><i class="fas fa-eye"></i> Lihat</button>
                                    <button class="btn btn-download"><i class="fas fa-download"></i> Coba Lagi</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fas fa-file-image file-icon"></i> Struktur Organisasi.jpg</td>
                            <td>Administrasi</td>
                            <td>03 Jan 2023, 08:30</td>
                            <td>1.1 MB</td>
                            <td><span class="status-badge status-completed">Berhasil</span></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-view"><i class="fas fa-eye"></i> Lihat</button>
                                    <button class="btn btn-download"><i class="fas fa-download"></i> Unduh Ulang</button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                <button class="page-btn"><i class="fas fa-chevron-left"></i></button>
                <button class="page-btn active">1</button>
                <button class="page-btn">2</button>
                <button class="page-btn">3</button>
                <button class="page-btn"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    </div>
</div>

<script>
// Dropdown functionality
function toggleDropdown() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('show');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const userInfo = document.querySelector('.user-info');
    const dropdown = document.getElementById('userDropdown');
    
    if (!userInfo.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});

// Close dropdown with ESC key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const dropdown = document.getElementById('userDropdown');
        dropdown.classList.remove('show');
    }
});

// Show/hide custom date range
document.getElementById('timePeriod').addEventListener('change', function() {
    const customDateRange = document.getElementById('customDateRange');
    if (this.value === 'custom') {
        customDateRange.style.display = 'block';
    } else {
        customDateRange.style.display = 'none';
    }
});

// Filter functionality
document.querySelector('.filter-btn').addEventListener('click', function() {
    const timePeriod = document.getElementById('timePeriod').value;
    alert('Filter diterapkan untuk periode: ' + timePeriod);
});

// Reset functionality
document.querySelector('.reset-btn').addEventListener('click', function() {
    document.getElementById('timePeriod').value = '7days';
    document.getElementById('customDateRange').style.display = 'none';
    document.querySelectorAll('.filter-select').forEach(select => {
        if (select.id !== 'timePeriod') {
            select.selectedIndex = 0;
        }
    });
    alert('Filter telah direset');
});

// Simulate view and download actions
document.querySelectorAll('.btn-view').forEach(btn => {
    btn.addEventListener('click', function() {
        const fileName = this.closest('tr').querySelector('td').textContent;
        alert('Melihat file: ' + fileName);
    });
});

document.querySelectorAll('.btn-download').forEach(btn => {
    btn.addEventListener('click', function() {
        const fileName = this.closest('tr').querySelector('td').textContent;
        const status = this.closest('tr').querySelector('.status-badge').textContent;
        
        if (status === 'Gagal') {
            alert('Mencoba mengunduh ulang file: ' + fileName);
        } else {
            alert('Mengunduh ulang file: ' + fileName);
        }
    });
});

// Set default dates for custom range
const today = new Date();
const oneWeekAgo = new Date(today);
oneWeekAgo.setDate(today.getDate() - 7);

document.getElementById('startDate').valueAsDate = oneWeekAgo;
document.getElementById('endDate').valueAsDate = today;
</script>
</body>
</html>