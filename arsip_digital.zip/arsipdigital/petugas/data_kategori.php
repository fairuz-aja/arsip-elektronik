<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "arsipdigital";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari tb_kategori
$sql = "SELECT * FROM tb_kategori";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kategori - Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #ec4899 0%, #be185d 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(236, 72, 153, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #f472b6, #ec4899);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #fecaca;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #fecaca, #fbb6ce);
            color: #be185d;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(254, 202, 202, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #ffffff, #fef7ff);
            padding: 15px 30px;
            box-shadow: 0 2px 20px rgba(236, 72, 153, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(236, 72, 153, 0.1);
        }
        
        .welcome-text h1 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .welcome-text p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: linear-gradient(45deg, #ec4899, #be185d);
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .user-info img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-info .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .user-info .user-role {
            font-size: 0.75rem;
            opacity: 0.9;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .page-header {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .page-header h4 {
            color: #be185d;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .data-card {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            overflow: hidden;
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .data-card-header {
            padding: 20px 25px;
            border-bottom: 1px solid rgba(244, 114, 182, 0.2);
            background: linear-gradient(45deg, #fefcff, #fdf2f8);
        }
        
        .data-card-header h5 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .data-card-body {
            padding: 25px;
        }
        
        /* Table Styling */
        .table {
            border-radius: 10px;
            overflow: hidden;
            margin: 0;
        }
        
        .table thead th {
            background: linear-gradient(45deg, #ec4899, #f43f5e);
            color: white;
            border: none;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
            padding: 15px;
        }
        
        .table tbody tr {
            transition: all 0.3s ease;
        }
        
        .table tbody tr:hover {
            background: linear-gradient(45deg, #fef7ff, #fdf2f8);
            transform: scale(1.01);
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.1);
        }
        
        .table tbody td {
            vertical-align: middle;
            border-color: rgba(244, 114, 182, 0.2);
            padding: 15px;
        }
        
        .table tbody tr:nth-child(even) {
            background-color: rgba(253, 242, 248, 0.3);
        }
        
        .no-data {
            text-align: center;
            color: #be185d;
            font-style: italic;
            padding: 30px;
        }
        
        .category-name {
            font-weight: 600;
            color: #be185d;
        }
        
        .category-description {
            color: #ec4899;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .data-card-body {
                padding: 15px;
                overflow-x: auto;
            }
            
            .table {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php">
            <i class="fas fa-folder-open"></i>
            Data Arsip
        </a>
        <a href="data_kategori.php" class="active">
            <i class="fas fa-tags"></i>
            Data Kategori
        </a>
        <a href="data_user.php">
            <i class="fas fa-users"></i>
            Data User
        </a>
        <a href="riwayat_unduh.php">
            <i class="fas fa-download"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="welcome-text">
            <h1>Data Kategori</h1>
        </div>
        
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=Petugas+4&background=ec4899&color=fff" alt="User">
            <div class="user-details">
                <div class="user-name">Petugas 4</div>
                <div class="user-role">Petugas</div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Data Kategori</span>
        </div>
        
        <!-- Page Header -->
        <div class="page-header">
            <h4><i class="fas fa-tags"></i> Data Kategori</h4>
        </div>

        <!-- Data Card -->
        <div class="data-card">
            <div class="data-card-header">
                <h5><i class="fas fa-list"></i> Semua Kategori</h5>
            </div>
            <div class="data-card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10%">No</th>
                                <th style="width: 30%">Nama Kategori</th>
                                <th style="width: 60%">Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                            <td class='text-center'><strong>{$no}</strong></td>
                                            <td class='category-name'>" . htmlspecialchars($row['nama_kategori']) . "</td>
                                            <td class='category-description'>" . htmlspecialchars($row['keterangan']) . "</td>
                                          </tr>";
                                    $no++;
                                }
                            } else {
                                echo "<tr><td colspan='3' class='no-data'><i class='fas fa-inbox'></i><br>Tidak ada data kategori</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Add some interactive effects
document.querySelectorAll('.table tbody tr').forEach(row => {
    if (!row.querySelector('.no-data')) {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.02)';
            this.style.zIndex = '1';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.zIndex = 'auto';
        });
    }
});

// Add loading animation effect
document.addEventListener('DOMContentLoaded', function() {
    const rows = document.querySelectorAll('.table tbody tr');
    rows.forEach((row, index) => {
        row.style.opacity = '0';
        row.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            row.style.transition = 'all 0.5s ease';
            row.style.opacity = '1';
            row.style.transform = 'translateY(0)';
        }, index * 100);
    });
});
</script>
</body>
</html>