<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Petugas - Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #ec4899 0%, #be185d 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(236, 72, 153, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #f472b6, #ec4899);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #fecaca;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #fecaca, #fbb6ce);
            color: #be185d;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(254, 202, 202, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #ffffff, #fef7ff);
            padding: 15px 30px;
            box-shadow: 0 2px 20px rgba(236, 72, 153, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(236, 72, 153, 0.1);
        }
        
        .welcome-text h1 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .welcome-text p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: linear-gradient(45deg, #ec4899, #be185d);
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .user-info img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-info .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .user-info .user-role {
            font-size: 0.75rem;
            opacity: 0.9;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(236, 72, 153, 0.25);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--card-color);
        }
        
        .stat-card.pink { --card-color: linear-gradient(45deg, #ec4899, #f472b6); }
        .stat-card.rose { --card-color: linear-gradient(45deg, #f43f5e, #fb7185); }
        .stat-card.purple { --card-color: linear-gradient(45deg, #a855f7, #c084fc); }
        .stat-card.magenta { --card-color: linear-gradient(45deg, #d946ef, #e879f9); }
        
        .stat-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stat-info h5 {
            color: #be185d;
            font-size: 0.9rem;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        .stat-info .number {
            font-size: 2.2rem;
            font-weight: bold;
            color: #9f1239;
            margin: 0;
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            position: relative;
        }
        
        .stat-icon::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: inherit;
            opacity: 0.2;
            transform: scale(1.2);
        }
        
        .stat-card.pink .stat-icon { background: linear-gradient(45deg, #ec4899, #f472b6); }
        .stat-card.rose .stat-icon { background: linear-gradient(45deg, #f43f5e, #fb7185); }
        .stat-card.purple .stat-icon { background: linear-gradient(45deg, #a855f7, #c084fc); }
        .stat-card.magenta .stat-icon { background: linear-gradient(45deg, #d946ef, #e879f9); }
        
        .mini-chart {
            margin-top: 15px;
            height: 40px;
            display: flex;
            align-items: end;
            gap: 3px;
        }
        
        .mini-bar {
            background: var(--card-color);
            opacity: 0.3;
            width: 8px;
            border-radius: 4px 4px 0 0;
        }
        
        .chart-section {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-top: 30px;
        }
        
        .chart-card {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            overflow: hidden;
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .chart-header {
            padding: 20px 25px;
            border-bottom: 1px solid rgba(244, 114, 182, 0.2);
            background: linear-gradient(45deg, #fefcff, #fdf2f8);
        }
        
        .chart-header h5 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
        }
        
        .chart-header small {
            color: #ec4899;
            font-size: 0.8rem;
        }
        
        .chart-body {
            padding: 25px;
        }
        
        .info-card {
            background: linear-gradient(135deg, #ec4899, #f43f5e);
            border-radius: 20px;
            padding: 25px;
            color: white;
            text-align: center;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.3);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .info-card .avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin-bottom: 15px;
            border: 3px solid rgba(255,255,255,0.3);
        }
        
        .info-card h4 {
            margin-bottom: 5px;
            font-size: 1.2rem;
        }
        
        .info-card .role {
            font-size: 0.9rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .info-card p {
            opacity: 0.8;
            font-size: 0.85rem;
            line-height: 1.4;
            margin: 0;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .chart-section {
                grid-template-columns: 1fr;
            }
            
            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php" class="active">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php">
            <i class="fas fa-folder-open"></i>
            Data Arsip
        </a>
        <a href="data_kategori.php">
            <i class="fas fa-tags"></i>
            Data Kategori
        </a>
        <a href="data_user.php">
            <i class="fas fa-users"></i>
            Data User
        </a>
        <a href="riwayat_unduh.php">
            <i class="fas fa-download"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="welcome-text">
            <h1>Dashboard</h1>
        </div>
        
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=Petugas+4&background=ec4899&color=fff" alt="User">
            <div class="user-details">
                <div class="user-name">Petugas 4</div>
                <div class="user-role">Petugas</div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Dashboard</span>
        </div>
        
        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card pink">
                <div class="stat-content">
                    <div class="stat-info">
                        <h5>Petugas</h5>
                        <p class="number">0</p>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-users-cog"></i>
                    </div>
                </div>
                <div class="mini-chart">
                    <div class="mini-bar" style="height: 20px;"></div>
                    <div class="mini-bar" style="height: 35px;"></div>
                    <div class="mini-bar" style="height: 25px;"></div>
                    <div class="mini-bar" style="height: 40px;"></div>
                    <div class="mini-bar" style="height: 30px;"></div>
                    <div class="mini-bar" style="height: 35px;"></div>
                </div>
            </div>
            
            <div class="stat-card rose">
                <div class="stat-content">
                    <div class="stat-info">
                        <h5>User / Pengguna</h5>
                        <p class="number">0</p>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="mini-chart">
                    <div class="mini-bar" style="height: 15px;"></div>
                    <div class="mini-bar" style="height: 25px;"></div>
                    <div class="mini-bar" style="height: 35px;"></div>
                    <div class="mini-bar" style="height: 20px;"></div>
                    <div class="mini-bar" style="height: 30px;"></div>
                    <div class="mini-bar" style="height: 40px;"></div>
                </div>
            </div>
            
            <div class="stat-card purple">
                <div class="stat-content">
                    <div class="stat-info">
                        <h5>Total Arsip</h5>
                        <p class="number">0</p>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-folder"></i>
                    </div>
                </div>
                <div class="mini-chart">
                    <div class="mini-bar" style="height: 30px;"></div>
                    <div class="mini-bar" style="height: 20px;"></div>
                    <div class="mini-bar" style="height: 40px;"></div>
                    <div class="mini-bar" style="height: 35px;"></div>
                    <div class="mini-bar" style="height: 25px;"></div>
                    <div class="mini-bar" style="height: 30px;"></div>
                </div>
            </div>
            
            <div class="stat-card magenta">
                <div class="stat-content">
                    <div class="stat-info">
                        <h5>Kategori Arsip</h5>
                        <p class="number">0</p>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-tags"></i>
                    </div>
                </div>
                <div class="mini-chart">
                    <div class="mini-bar" style="height: 25px;"></div>
                    <div class="mini-bar" style="height: 35px;"></div>
                    <div class="mini-bar" style="height: 20px;"></div>
                    <div class="mini-bar" style="height: 40px;"></div>
                    <div class="mini-bar" style="height: 30px;"></div>
                    <div class="mini-bar" style="height: 25px;"></div>
                </div>
            </div>
        </div>

        <!-- Chart Section -->
        <div class="chart-section">
            <div class="chart-card">
                <div class="chart-header">
                    <h5><i class="fas fa-chart-line me-2"></i>Grafik Pengunduhan Arsip</h5>
                    <small class="text-muted">Grafik jumlah unduh arsip perhari selama sebulan</small>
                </div>
                <div class="chart-body">
                    <canvas id="grafikUnduh" height="100"></canvas>
                </div>
            </div>
            
            <div class="info-card">
                <div class="avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h4>Petugas 4</h4>
                <div class="role">Petugas</div>
                <p>Pengelolaan arsip jadi lebih mudah dengan sistem informasi arsip digital.</p>
            </div>
        </div>
    </div>
</div>

<script>
// Sample data for chart
const sampleDates = ['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-06', '2024-01-07'];
const sampleData = [0, 1, 0, 2, 1, 3, 1];

const ctx = document.getElementById('grafikUnduh');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: sampleData.map((_, index) => `Hari ${index + 1}`),
        datasets: [{
            label: 'Jumlah Unduhan',
            data: sampleData,
            borderColor: '#ec4899',
            backgroundColor: 'rgba(236, 72, 153, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#ec4899',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverRadius: 8,
            pointHoverBackgroundColor: '#f43f5e',
            pointHoverBorderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    usePointStyle: true,
                    font: {
                        size: 12
                    },
                    color: '#be185d'
                }
            }
        },
        scales: {
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    font: {
                        size: 11
                    },
                    color: '#be185d'
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(236, 72, 153, 0.1)'
                },
                ticks: {
                    font: {
                        size: 11
                    },
                    color: '#be185d'
                }
            }
        },
        elements: {
            point: {
                hoverBackgroundColor: '#ec4899'
            }
        }
    }
});

// Add some interactive effects
document.querySelectorAll('.stat-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-12px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0) scale(1)';
    });
});
</script>
</body>
</html>