<?php
// data_arsip.php

session_start();
include "../config/koneksi.php"; // koneksi ke database

// cek login
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

// ambil data arsip dari database
$query = "SELECT * FROM arsip ORDER BY waktu_upload DESC";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Arsip - Arsip Digital</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, #ec4899 0%, #be185d 100%);
            color: white;
            padding: 0;
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(236, 72, 153, 0.3);
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: linear-gradient(45deg, #f472b6, #ec4899);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h4 {
            color: #ffffff;
            font-weight: bold;
            margin: 0;
            font-size: 1.4rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar-header .subtitle {
            font-size: 0.8rem;
            color: rgba(255,255,255,0.8);
            margin-top: 5px;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
            border-left-color: #fecaca;
            backdrop-filter: blur(10px);
        }
        
        .sidebar-menu a.active {
            background: linear-gradient(45deg, #fecaca, #fbb6ce);
            color: #be185d;
            border-left-color: #ffffff;
            box-shadow: 0 4px 15px rgba(254, 202, 202, 0.4);
            font-weight: 600;
        }
        
        .sidebar-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 0;
            background: linear-gradient(135deg, #fdf2f8 0%, #fce7f3 50%, #fbcfe8 100%);
            min-height: 100vh;
        }
        
        .top-navbar {
            background: linear-gradient(45deg, #ffffff, #fef7ff);
            padding: 15px 30px;
            box-shadow: 0 2px 20px rgba(236, 72, 153, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(236, 72, 153, 0.1);
        }
        
        .welcome-text h1 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            font-size: 1.8rem;
        }
        
        .welcome-text p {
            color: #ec4899;
            margin-top: 5px;
            font-size: 0.9rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            background: linear-gradient(45deg, #ec4899, #be185d);
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .user-info img {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-info .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .user-info .user-role {
            font-size: 0.75rem;
            opacity: 0.9;
        }
        
        .main-content {
            padding: 30px;
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .breadcrumb i {
            margin: 0 8px;
            opacity: 0.6;
        }
        
        .alert {
            background: linear-gradient(45deg, #dcfce7, #bbf7d0);
            color: #166534;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            border: 1px solid #86efac;
            box-shadow: 0 4px 15px rgba(34, 197, 94, 0.1);
            display: flex;
            align-items: center;
        }
        
        .alert i {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        
        .card {
            background: linear-gradient(145deg, #ffffff, #fefcff);
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(236, 72, 153, 0.15);
            overflow: hidden;
            border: 1px solid rgba(244, 114, 182, 0.2);
        }
        
        .card-header {
            padding: 20px 25px;
            border-bottom: 1px solid rgba(244, 114, 182, 0.2);
            background: linear-gradient(45deg, #fefcff, #fdf2f8);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h5 {
            margin: 0;
            color: #be185d;
            font-weight: 600;
            display: flex;
            align-items: center;
        }
        
        .card-header h5 i {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            font-size: 0.9rem;
            cursor: pointer;
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, #ec4899, #be185d);
            color: white;
            box-shadow: 0 4px 15px rgba(236, 72, 153, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(236, 72, 153, 0.4);
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.8rem;
            margin: 2px;
        }
        
        .btn-dark {
            background: linear-gradient(45deg, #374151, #1f2937);
            color: white;
            box-shadow: 0 4px 15px rgba(55, 65, 81, 0.3);
        }
        
        .btn-warning {
            background: linear-gradient(45deg, #f59e0b, #d97706);
            color: white;
            box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);
        }
        
        .btn-danger {
            background: linear-gradient(45deg, #ef4444, #dc2626);
            color: white;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }
        
        .btn-dark:hover, .btn-warning:hover, .btn-danger:hover {
            transform: translateY(-2px);
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* DataTable Styling */
        .dataTables_wrapper {
            margin-top: 20px;
        }
        
        .dataTables_length select,
        .dataTables_filter input {
            padding: 8px 12px;
            border: 2px solid rgba(244, 114, 182, 0.2);
            border-radius: 25px;
            background: white;
            color: #be185d;
            font-size: 0.9rem;
        }
        
        .dataTables_length select:focus,
        .dataTables_filter input:focus {
            outline: none;
            border-color: #ec4899;
            box-shadow: 0 0 0 3px rgba(236, 72, 153, 0.1);
        }
        
        .dataTables_length label,
        .dataTables_filter label {
            color: #be185d;
            font-weight: 600;
        }
        
        table.dataTable {
            border-collapse: separate;
            border-spacing: 0;
            width: 100% !important;
        }
        
        table.dataTable thead th {
            background: linear-gradient(45deg, #fce7f3, #fbcfe8);
            color: #be185d;
            font-weight: 600;
            padding: 15px 10px;
            border: none;
            text-align: center;
            font-size: 0.9rem;
        }
        
        table.dataTable thead th:first-child {
            border-radius: 12px 0 0 0;
        }
        
        table.dataTable thead th:last-child {
            border-radius: 0 12px 0 0;
        }
        
        table.dataTable tbody td {
            padding: 12px 10px;
            border-bottom: 1px solid rgba(244, 114, 182, 0.1);
            color: #374151;
            font-size: 0.85rem;
            vertical-align: middle;
        }
        
        table.dataTable tbody tr:hover {
            background: linear-gradient(45deg, #fef7ff, #fdf2f8);
        }
        
        table.dataTable tbody tr:nth-child(even) {
            background: rgba(254, 247, 255, 0.3);
        }
        
        .dataTables_info,
        .dataTables_paginate {
            color: #be185d !important;
            font-weight: 600;
        }
        
        .dataTables_paginate .paginate_button {
            padding: 8px 12px !important;
            margin: 0 2px !important;
            border-radius: 8px !important;
            border: 1px solid rgba(244, 114, 182, 0.2) !important;
            background: white !important;
            color: #be185d !important;
        }
        
        .dataTables_paginate .paginate_button:hover {
            background: linear-gradient(45deg, #fce7f3, #fbcfe8) !important;
            color: #be185d !important;
        }
        
        .dataTables_paginate .paginate_button.current {
            background: linear-gradient(45deg, #ec4899, #be185d) !important;
            color: white !important;
        }
        
        .archive-info {
            line-height: 1.4;
        }
        
        .archive-info strong {
            color: #be185d;
            font-weight: 600;
        }
        
        .archive-info br {
            margin-bottom: 5px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .content {
                margin-left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .top-navbar {
                padding: 15px 20px;
            }
            
            .btn-sm {
                padding: 4px 8px;
                font-size: 0.75rem;
            }
            
            table.dataTable {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h4><i class="fas fa-archive"></i> ARSIP</h4>
        <div class="subtitle">Digital Archive System</div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            Dashboard
        </a>
        <a href="data_arsip.php" class="active">
            <i class="fas fa-folder-open"></i>
           Data Arsip
        </a>
        <a href="data_kategori.php">
            <i class="fas fa-tags"></i>
            Data Kategori
        </a>
        <a href="data_user.php">
            <i class="fas fa-users"></i>
            Data User
        </a>
        <a href="riwayat_unduh.php">
            <i class="fas fa-download"></i>
            Riwayat Unduh
        </a>
        <a href="ganti_password.php">
            <i class="fas fa-key"></i>
            Ganti Password
        </a>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="welcome-text">
            <h1>Data Arsip Saya</h1>
            <p>Kelola dan pantau semua arsip digital Anda</p>
        </div>
        
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=Petugas+4&background=ec4899&color=fff" alt="User">
            <div class="user-details">
                <div class="user-name">Petugas 4</div>
                <div class="user-role">Petugas</div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Breadcrumb -->
        <div class="breadcrumb">
            <span>Home</span>
            <i class="fas fa-chevron-right"></i>
            <span>Data Arsip</span>
        </div>

       <?php if (isset($_GET['sukses'])) { 
    if ($_GET['sukses'] == "tambah") { ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            Arsip berhasil tersimpan.
        </div>
    <?php } elseif ($_GET['sukses'] == "update") { ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            Arsip berhasil diperbarui.
        </div>
    <?php } elseif ($_GET['sukses'] == "hapus") { ?>
        <div class="alert">
            <i class="fas fa-check-circle"></i>
            Arsip berhasil dihapus.
        </div>
<?php } } ?>

        <div class="card">
            <div class="card-header">
                <h5>
                    <i class="fas fa-folder-open"></i>
                    Daftar Arsip
                </h5>
                <a href="upload_arsip.php" class="btn btn-primary">
                    <i class="fas fa-cloud-upload-alt"></i>
                    Upload Arsip
                </a>
            </div>
            <div class="card-body">
                <table id="tabelArsip" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Waktu Upload</th>
                            <th>Arsip</th>
                            <th>Kategori</th>
                            <th>Petugas</th>
                            <th>Keterangan</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_assoc($result)){ ?>
                                <tr>
                                    <td style="text-align: center; font-weight: 600;"><?= $no++ ?></td>
                                    <td style="text-align: center; font-weight: 500;">
                                        <?= date('H:i:s d-m-Y', strtotime($row['waktu_upload'])) ?>
                                    </td>
                                    <td class="archive-info">
                                        <strong>KODE:</strong> <?= htmlspecialchars($row['kode_arsip']) ?><br>
                                        <strong>Nama:</strong> <?= htmlspecialchars($row['nama_arsip']) ?><br>
                                        <strong>Jenis:</strong> <?= strtoupper(pathinfo($row['file_path'], PATHINFO_EXTENSION)) ?>
                                    </td>
                                    <td style="text-align: center; font-weight: 500;">
                                        <?= htmlspecialchars($row['kategori']) ?>
                                    </td>
                                    <td style="text-align: center; font-weight: 500;">
                                        <?= htmlspecialchars($row['petugas']) ?>
                                    </td>
                                    <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                    <td style="text-align: center;">
                                        <a href="preview_arsip.php?id=<?= $row['id'] ?>" class="btn btn-dark btn-sm">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="edit_arsip.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="hapus_arsip.php?id=<?= $row['id'] ?>" 
                                           onclick="return confirm('Yakin ingin hapus arsip ini?')" 
                                           class="btn btn-danger btn-sm">
                                           <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                        <?php }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#tabelArsip').DataTable({
        "language": {
            "lengthMenu": "Tampilkan _MENU_ data per halaman",
            "zeroRecords": "Data tidak ditemukan",
            "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
            "infoEmpty": "Tidak ada data yang tersedia",
            "infoFiltered": "(difilter dari _MAX_ total data)",
            "search": "Cari:",
            "paginate": {
                "first": "Pertama",
                "last": "Terakhir",
                "next": "Selanjutnya",
                "previous": "Sebelumnya"
            }
        },
        "pageLength": 10,
        "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "Semua"]],
        "responsive": true,
        "order": [[ 1, "desc" ]]
    });

    // Add hover effects to buttons
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px) scale(1.05)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
});
</script>

</body>
</html>