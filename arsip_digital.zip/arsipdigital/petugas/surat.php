<?php
// surat.php
session_start();
include "../config/koneksi.php";

// cek login
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit;
}

// ambil semua data surat
$query = mysqli_query($koneksi, "SELECT * FROM tb_arsip ORDER BY id_arsip DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Surat - Sistem Informasi Arsip Digital</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-4">
    <h3 class="mb-4">📄 Data Surat</h3>
    <a href="tambah_surat.php" class="btn btn-primary mb-3">+ Tambah Surat</a>
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>No</th>
          <th>Kode Arsip</th>
          <th>Nama Surat</th>
          <th>Jenis Surat</th>
          <th>Tanggal Upload</th>
          <th>File Surat</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        while ($row = mysqli_fetch_assoc($query)) {
            echo "<tr>";
            echo "<td>".$no++."</td>";
            echo "<td>".$row['kode_arsip']."</td>";
            echo "<td>".$row['nama']."</td>";
            echo "<td>".$row['jenis_file']."</td>";
            echo "<td>".$row['tanggal_upload']."</td>";
            
            // tampilkan file surat
            if (!empty($row['file_surat']) && file_exists("../uploads/".$row['file_surat'])) {
                echo "<td><a href='../uploads/".$row['file_surat']."' target='_blank' class='btn btn-sm btn-success'>Lihat/Download</a></td>";
            } else {
                echo "<td><span class='badge bg-danger'>Tidak ada file</span></td>";
            }

            echo "<td>
                    <a href='edit_surat.php?id=".$row['id_arsip']."' class='btn btn-sm btn-warning'>Edit</a>
                    <a href='hapus_surat.php?id=".$row['id_arsip']."' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin hapus?\")'>Hapus</a>
                  </td>";
            echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>
