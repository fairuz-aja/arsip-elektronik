<?php
// register.php
session_start();
include 'config/koneksi.php';
$pesan = "";

if (isset($_POST['register'])) {
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $konfirmasi = mysqli_real_escape_string($koneksi, $_POST['konfirmasi']);

    // Validasi input
    if (empty($nama_lengkap) || empty($username) || empty($password) || empty($konfirmasi)) {
        $pesan = "<div style='color:red;margin-bottom:10px;'>Semua field harus diisi!</div>";
    } elseif (strlen($username) < 3) {
        $pesan = "<div style='color:red;margin-bottom:10px;'>Username minimal 3 karakter!</div>";
    } elseif (strlen($password) < 6) {
        $pesan = "<div style='color:red;margin-bottom:10px;'>Password minimal 6 karakter!</div>";
    } else {
        // Cek username yang sudah ada
        $cek = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$username'");
        if (mysqli_num_rows($cek) > 0) {
            $pesan = "<div style='color:red;margin-bottom:10px;'>Username sudah dipakai! Silakan pilih username lain.</div>";
        } elseif ($password !== $konfirmasi) {
            $pesan = "<div style='color:red;margin-bottom:10px;'>Konfirmasi password tidak cocok!</div>";
        } else {
            // Hash password dan simpan user baru
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $simpan = mysqli_query($koneksi, "INSERT INTO tb_user (nama_user, username, password) VALUES ('$nama_lengkap', '$username', '$password_hash')");
            
            if ($simpan) {
                $_SESSION['registration_success'] = "Registrasi berhasil! Silakan login dengan akun yang baru dibuat.";
                header("Location: login_user.php");
                exit;
            } else {
                $pesan = "<div style='color:red;margin-bottom:10px;'>Terjadi kesalahan saat menyimpan data!</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Registrasi User | Sistem Informasi Arsip Digital</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<style>
    .login-page { 
        background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        display: flex; 
        justify-content: center; 
        align-items: center; 
        min-height: 100vh;
        font-family: 'Arial', sans-serif;
    }
    .login-box { 
        background-color: white; 
        padding: 40px; 
        width: 450px; 
        border-radius: 15px; 
        text-align: center; 
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        transition: transform 0.3s ease;
    }
    .login-box:hover {
        transform: translateY(-5px);
    }
    .login-box h2 { 
        margin-bottom: 10px; 
        font-size: 24px; 
        color: #333;
        font-weight: bold;
    }
    .login-box p { 
        margin-bottom: 25px; 
        color: #666; 
    }
    .login-box form h3 { 
        margin-bottom: 20px; 
        color: #333;
        background: linear-gradient(45deg, #28a745, #20c997);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-weight: bold;
    }
    .login-box label { 
        display: block; 
        text-align: left; 
        margin-bottom: 5px; 
        font-size: 14px;
        color: #555;
        font-weight: 500;
    }
    .login-box input { 
        width: 100%; 
        padding: 12px; 
        margin-bottom: 15px; 
        border-radius: 8px; 
        border: 2px solid #e1e1e1;
        transition: border-color 0.3s ease;
        font-size: 14px;
        box-sizing: border-box;
    }
    .login-box input:focus {
        outline: none;
        border-color: #28a745;
        box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
    }
    .login-box button { 
        width: 100%; 
        padding: 12px; 
        background: linear-gradient(45deg, #28a745, #20c997);
        border: none; 
        color: white; 
        font-size: 16px; 
        border-radius: 8px; 
        cursor: pointer;
        transition: transform 0.2s ease;
        font-weight: 600;
    }
    .login-box button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
    }
    .btn-back { 
        display: inline-block; 
        margin: 5px; 
        text-decoration: none; 
        background-color: #6c757d; 
        color: white; 
        padding: 10px 20px; 
        border-radius: 8px;
        transition: all 0.3s ease;
        font-weight: 500;
    }
    .btn-back:hover {
        background-color: #5a6268;
        transform: translateY(-2px);
    }
    .info-box {
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 20px;
        color: #0c5460;
        font-size: 14px;
    }
    .password-info {
        font-size: 12px;
        color: #6c757d;
        margin-top: -10px;
        margin-bottom: 15px;
        text-align: left;
    }
    .form-row {
        display: flex;
        gap: 15px;
        margin-bottom: 15px;
    }
    .form-row .form-group {
        flex: 1;
    }
    .form-row .form-group label {
        margin-bottom: 5px;
    }
    .form-row .form-group input {
        margin-bottom: 0;
    }
</style>
<body class="login-page">
    <div class="login-box">
        <h2>SISTEM INFORMASI<br>ARSIP DIGITAL</h2>
        <p>Silahkan daftar untuk membuat akun baru.</p>
        
        <div class="info-box">
            <strong>Informasi Registrasi:</strong><br>
            Setelah berhasil mendaftar, Anda akan diarahkan ke halaman login untuk masuk dengan akun yang telah dibuat.
        </div>
        
        <?php echo $pesan; ?>
        
        <form method="post">
            <h3>REGISTRASI USER</h3>
            
            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" required placeholder="Masukkan nama lengkap Anda" 
                   value="<?php echo isset($_POST['nama_lengkap']) ? htmlspecialchars($_POST['nama_lengkap']) : ''; ?>">
            
            <label>Username</label>
            <input type="text" name="username" required placeholder="Minimal 3 karakter (contoh: user123)" 
                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">

            <div class="form-row">
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required placeholder="Minimal 6 karakter">
                </div>
                <div class="form-group">
                    <label>Konfirmasi Password</label>
                    <input type="password" name="konfirmasi" required placeholder="Ulangi password">
                </div>
            </div>
            <div class="password-info">* Password harus minimal 6 karakter dan konfirmasi password harus sama</div>

            <button type="submit" name="register">Daftar Sekarang</button>
            
            <div style="margin-top: 15px;">
                <a href="login_user.php" class="btn-back">Sudah Punya Akun? Login</a>
            </div>
        </form>
    </div>
</body>
</html>